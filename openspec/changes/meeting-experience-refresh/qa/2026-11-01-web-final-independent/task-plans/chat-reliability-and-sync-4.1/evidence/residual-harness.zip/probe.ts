import { QueryClient } from '@tanstack/react-query';
import { loadChat } from '/Users/misha/Documents/Codex/projects/group-planning/frontend/web/src/entities/meeting/model/loadChat';
import { accessEpoch, privateKey, resetAccess, denyAccess } from '/Users/misha/Documents/Codex/projects/group-planning/frontend/web/src/entities/meeting/model/access';
import { getChatSnapshot } from '/Users/misha/Documents/Codex/projects/group-planning/frontend/web/src/entities/meeting/api/chat';
import { snapshotConversation } from '/Users/misha/Documents/Codex/projects/group-planning/frontend/web/src/entities/meeting/model/chatState';
import { applyChatChanges } from '/Users/misha/Documents/Codex/projects/group-planning/frontend/web/src/entities/meeting/model/chatState';
import { openPrivateScope, updatePrivateScope, readPrivateScope, observePrivateStore } from '/Users/misha/Documents/Codex/projects/group-planning/frontend/web/src/shared/lib/private-store';
const client = new QueryClient({ defaultOptions: { queries: { retry: false } } });
let user = '', meeting = '', epoch = 0, inFlight = 0, maxInFlight = 0, heldScope: Awaited<ReturnType<typeof openPrivateScope>> | undefined;
let failFeedCommit = false;
const realSet = client.setQueryData.bind(client);
client.setQueryData = ((key: readonly unknown[], value: unknown, options?: unknown) => {
  if (failFeedCommit && key[4] === 'feed') { failFeedCommit = false; throw Error('independent controlled feed storage/apply failure'); }
  return realSet(key, value, options as never);
}) as typeof client.setQueryData;
const key = () => privateKey(user, meeting, epoch, 'feed');
const state = () => client.getQueryData(key());
const load = async () => { inFlight++; maxInFlight = Math.max(maxInFlight,inFlight); try { return await loadChat(client,user,meeting,epoch); } finally { inFlight--; } };
(globalThis as any).__sdd = {
  async init(u:string,m:string) { user=u;meeting=m;resetAccess();epoch=accessEpoch(user,meeting);client.clear();await load();return state(); },
  load, state,
  async anchor(id:string) { const page=await getChatSnapshot(meeting,undefined,id);const value=snapshotConversation(page);client.setQueryData(key(),value);return value; },
  metrics: () => ({inFlight,maxInFlight}),
  failNextFeedCommit: () => {failFeedCommit=true;},
  replay: (page:unknown) => {const next=applyChatChanges(state() as never,page as never,user);client.setQueryData(key(),next);return next;},
  async holdStorage(u:string,m:string) { observePrivateStore(()=>{}); heldScope=await openPrivateScope(u,m); return {user:heldScope.user,meeting:heldScope.meeting}; },
  async lateStorage() { try { await updatePrivateScope(heldScope!,()=>({draft:'STALE PRIVATE A',intents:[{id:'OLD A'}]})); return {accepted:true}; } catch(error) { return {accepted:false,name:(error as Error).name,message:(error as Error).message}; } },
  async readHeldStorage() { try { return await readPrivateScope(heldScope!); } catch(error) {return {expired:true,name:(error as Error).name};} },
  deny: () => {denyAccess(client,user,meeting,epoch);return state();},
};
