import {test,expect} from '/Users/misha/Documents/Codex/projects/group-planning/node_modules/@playwright/test/index.mjs';
import {apiCreate,login,writeHeaders} from '/Users/misha/Documents/Codex/projects/group-planning/frontend/web/tests/helpers.ts';
import {postMessage} from '/Users/misha/Documents/Codex/projects/group-planning/frontend/web/tests/helpers/readChat.ts';
import {createHash} from 'node:crypto';
import fs from 'node:fs/promises';
const sha=x=>createHash('sha256').update(x).digest('hex');
const dir='/tmp/somewhere-web-sdd-independent/final/chat-residual/evidence';
for(const width of [1440,390])for(const fault of ['replayed-page','failed-apply'])test(`THROUGH actualGo ${width} ${fault}`,async({page})=>{
 await page.setViewportSize({width,height:900});await login(page,'Саша');const {meeting}=await apiCreate(page,'Independent THROUGH '+fault),id=meeting.id,headers=await writeHeaders(page),me=await(await page.request.get('/api/v1/me')).json();
 await page.goto('/profile');await page.addScriptTag({path:'/tmp/somewhere-web-sdd-independent/final/chat-residual/probe.js'});
 const initial=await page.evaluate(async({u,id})=>await window.__sdd.init(u,id),{u:me.user.id,id});expect(initial.sync).toBeTruthy();
 for(let i=1;i<=110;i++)await postMessage(page,id,headers,'bounded-'+i);
 const events=[];let first,secondCursor,firstThrough,gateSeen=false,faultSent=false,late;
 await page.route(`**/api/v1/meetings/${id}/sync?*`,async route=>{
  const params=new URL(route.request().url()).searchParams,cur=params.get('cursor');
  if(!cur){await route.continue();return;}
  const response=await route.fetch(),body=await response.json();
  events.push({requestCursorSHA:sha(cur),nextSHA:sha(body.next_cursor),throughSHA:sha(body.through_cursor),more:body.has_more,count:body.changes.length,entryTexts:body.changes.flatMap(c=>c.projection?.entry?.text?[c.projection.entry.text]:[])});
  if(!first){first=body;firstThrough=body.through_cursor;secondCursor=body.next_cursor;expect(body.changes.length).toBe(100);expect(body.has_more).toBe(true);late=await postMessage(page,id,headers,'AFTER-THROUGH-TPLUS1');}
  else if(!faultSent&&cur===secondCursor){faultSent=true;if(fault==='replayed-page'){await route.fulfill({response,json:first});return;}await page.evaluate(()=>window.__sdd.failNextFeedCommit());}
  await route.fulfill({response,json:body});
 });
 const failure=await page.evaluate(async()=>{try{await window.__sdd.load();return '';}catch(e){return e.message;}});expect(failure).toContain(fault==='replayed-page'?'Invalid sync boundary':'independent controlled feed storage/apply failure');
 const partial=await page.evaluate(()=>window.__sdd.state());expect(partial.sync.cursor).toBe(secondCursor);expect(partial.entries.some(e=>e.text==='AFTER-THROUGH-TPLUS1')).toBe(false);
 const complete=await page.evaluate(()=>window.__sdd.load());expect(complete.sync.cursor).toBe(firstThrough);expect(complete.entries.some(e=>e.text==='AFTER-THROUGH-TPLUS1')).toBe(false);
 const next=await page.evaluate(()=>window.__sdd.load());expect(next.entries.filter(e=>e.text==='AFTER-THROUGH-TPLUS1')).toHaveLength(1);expect(next.latestSequence).toBe(late.sequence);expect(new Set(next.entries.map(e=>e.id)).size).toBe(next.entries.length);
 expect(await page.evaluate(()=>window.__sdd.metrics())).toEqual({inFlight:0,maxInFlight:1});
 await fs.writeFile(`${dir}/through-${width}-${fault}.json`,JSON.stringify({width,fault,initialCursorSHA:sha(initial.sync.cursor),barrierSHA:sha(firstThrough),partialCursorSHA:sha(partial.sync.cursor),completeCursorSHA:sha(complete.sync.cursor),nextCursorSHA:sha(next.sync.cursor),failure,lateSequence:late.sequence,retainedUniqueEntries:next.entries.length,events},null,2));
});
