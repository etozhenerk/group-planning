import {test,expect} from '/Users/misha/Documents/Codex/projects/group-planning/node_modules/@playwright/test/index.mjs';
import {apiCreate,login,writeHeaders} from '/Users/misha/Documents/Codex/projects/group-planning/frontend/web/tests/helpers.ts';
import {postMessage,readChat} from '/Users/misha/Documents/Codex/projects/group-planning/frontend/web/tests/helpers/readChat.ts';
import {randomUUID} from 'node:crypto';
import fs from 'node:fs/promises';
const dir='/tmp/somewhere-web-sdd-independent/final/chat-residual/evidence';
const privateRows=page=>page.evaluate(()=>new Promise((resolve,reject)=>{const r=indexedDB.open('somewhere-private-chat',1);r.onerror=()=>reject(r.error);r.onsuccess=()=>{const db=r.result,t=db.transaction('records'),s=t.objectStore('records'),keys=s.getAllKeys(),values=s.getAll();t.oncomplete=()=>{resolve({keys:keys.result,values:values.result});db.close();};t.onerror=()=>reject(t.error);};}));
for(const width of [1440,390])test(`logout login X releases old sync send read and storage ${width}`,async({page,browser,context})=>{
 await page.setViewportSize({width,height:900});const setup=await readChat(page,browser,'Independent stale callbacks'),id=setup.meeting.id,me=await(await page.request.get('/api/v1/me')).json();
 const control=await context.newPage();const pending=[],events=[];let release;const barrier=new Promise(r=>release=r);
 const hold=async(kind,route)=>{const response=await route.fetch();expect(response.ok()).toBe(true);pending.push(kind);events.push({kind,phase:'committed-before-logout',status:response.status()});await barrier;try{await route.fulfill({response});events.push({kind,phase:'released-after-login-X'});}catch{events.push({kind,phase:'already-aborted-by-owner'});}};
 try{
 await postMessage(setup.friend,id,setup.friendHeaders,'A PRIVATE INITIAL');
 await page.route(`**/api/v1/meetings/${id}/read-marker`,r=>hold('read',r));
 await page.goto(`/meetings/${id}`);await expect(page.getByText('A PRIVATE INITIAL',{exact:true})).toBeVisible();await expect.poll(()=>pending.includes('read')).toBe(true);
 await page.addScriptTag({path:'/tmp/somewhere-web-sdd-independent/final/chat-residual/probe.js'});await page.evaluate(({u,id})=>window.__sdd.holdStorage(u,id),{u:me.user.id,id});
 await page.route(`**/api/v1/meetings/${id}/sync?*`,r=>{if(new URL(r.request().url()).searchParams.has('cursor'))return hold('sync',r);return r.continue();});
 await postMessage(setup.friend,id,setup.friendHeaders,'A PRIVATE LATE SYNC');await expect.poll(()=>pending.includes('sync')).toBe(true);
 await page.route(`**/api/v1/meetings/${id}/messages`,r=>hold('send',r));
 await page.getByLabel('Сообщение',{exact:true}).fill('A PRIVATE LATE ACK');await page.getByRole('button',{name:'Отправить сообщение',exact:true}).click();await expect.poll(()=>pending.includes('send')).toBe(true);
 await control.goto('/profile');await control.getByRole('button',{name:'Выйти из аккаунта',exact:true}).click();await expect(page.getByLabel('Сообщение',{exact:true})).toHaveCount(0);
 await control.goto('/meetings');await control.getByRole('button',{name:'Войти через Яндекс ID'}).click();await control.getByRole('link',{name:'Войти как Аня',exact:true}).click();await expect(control).toHaveURL(/\/meetings$/);const x=await(await control.request.get('/api/v1/me')).json();expect(x.user.id).not.toBe(me.user.id);expect(x.user.display_name).toBe('Аня');
 const lateStorage=await page.evaluate(()=>window.__sdd.lateStorage());expect(lateStorage.accepted).toBe(false);expect(lateStorage.name).toBe('AbortError');release();await expect.poll(()=>events.filter(e=>e.phase!=='committed-before-logout').length).toBeGreaterThanOrEqual(3);
 expect((await control.request.get(`/api/v1/meetings/${id}/feed`)).status()).toBe(403);expect((await control.request.get(`/api/v1/meetings/${id}/sync?limit=50`)).status()).toBe(403);
 const rows=await privateRows(control);expect(rows.keys.filter(k=>Array.isArray(k)&&k[0]===me.user.id)).toEqual([]);expect(JSON.stringify(rows.values)).not.toContain('A PRIVATE');await expect(page.locator('body')).not.toContainText('A PRIVATE');
 await fs.writeFile(`${dir}/account-switch-${width}.json`,JSON.stringify({width,pendingKinds:[...new Set(pending)].sort(),events,lateStorage,newAccount:'Аня',previousRecordsRemaining:0,newAccountFeedStatus:403,newAccountSyncStatus:403,privateTextRestored:false},null,2));await control.screenshot({path:`${dir}/account-switch-${width}.png`});
 }finally{release();await page.unrouteAll({behavior:'ignoreErrors'});await control.close();await setup.context.close();}
});
