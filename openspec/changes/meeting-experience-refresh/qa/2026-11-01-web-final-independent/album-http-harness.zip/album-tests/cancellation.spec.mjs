import {test,expect} from '/Users/misha/Documents/Codex/projects/group-planning/node_modules/@playwright/test/index.mjs';
import {login} from '/Users/misha/Documents/Codex/projects/group-planning/frontend/web/tests/helpers.ts';
import {seedExportAlbum,archivePhotos} from '/Users/misha/Documents/Codex/projects/group-planning/frontend/web/tests/helpers/albumExport.ts';
import fs from 'node:fs/promises';import crypto from 'node:crypto';
const out='/tmp/somewhere-web-sdd-independent/final/album-evidence';
for(const width of [390,1440])for(const fault of ['late-ack','lost-ack','failed-delete'])test(`cancel before real server ACK ${fault} at ${width}`,async({page})=>{
 await fs.mkdir(out,{recursive:true});await page.setViewportSize({width,height:900});await login(page,'Саша');const album=await seedExportAlbum(page),base=`/api/v1/meetings/${album.id}/memories/exports`,events=[];let posts=0,deletes=0,committed=false,oldId;let release;const gate=new Promise(r=>release=r);const keys=[];const mark=(event,extra={})=>events.push({at:new Date().toISOString(),event,...extra});
 page.on('requestfailed',r=>{if(new URL(r.url()).pathname.startsWith(base))mark('browser.requestfailed',{method:r.method(),path:new URL(r.url()).pathname,error:r.failure()?.errorText});});
 await page.route(`**${base}`,async route=>{
  const request=route.request();if(request.method()!=='POST'){await route.continue();return;}posts++;const n=posts,key=request.headers()['idempotency-key'];keys.push(crypto.createHash('sha256').update(key??'').digest('hex'));mark('POST.request',{number:n,keyHash:keys.at(-1)});
  const response=await route.fetch(),body=await response.json();mark('POST.server.response',{number:n,status:response.status(),id:body.id,error:body.error?.code});
  expect(response.status()).toBe(202);
  if(n===1){oldId=body.id;committed=true;await gate;if(fault==='lost-ack'){await route.abort('connectionreset');return;}}
  if(fault==='lost-ack'&&n===2)expect(body.id).toBe(oldId);
  await route.fulfill({response});mark('POST.browser.fulfilled',{number:n});
 });
 await page.route(`**${base}/*`,async route=>{
  if(route.request().method()!=='DELETE'){await route.continue();return;}deletes++;mark('DELETE.request',{number:deletes,path:new URL(route.request().url()).pathname});
  if(fault==='failed-delete'&&deletes===1){await route.abort('failed');mark('DELETE.injected.failure');return;}
  const response=await route.fetch();mark('DELETE.server.response',{number:deletes,status:response.status()});expect(response.status()).toBe(204);await route.fulfill({response});
 });
 let downloaded=0;page.on('download',()=>downloaded++);
 try{
  await page.goto(`/meetings/${album.id}/memories`);await page.getByRole('button',{name:'Скачать все фото',exact:true}).click();await expect.poll(()=>committed).toBe(true);await expect(page.getByRole('button',{name:'Отменить подготовку фотографий'})).toBeVisible();await page.screenshot({path:`${out}/${width}-${fault}-preparing.png`});
  await page.getByRole('button',{name:'Отменить подготовку фотографий'}).click();mark('UI.cancel');await expect(page.getByRole('button',{name:'Скачать все фото',exact:true})).toBeVisible();expect(downloaded).toBe(0);
  await page.getByRole('button',{name:'Скачать все фото',exact:true}).click();mark('UI.explicit.restart');await expect(page.getByRole('button',{name:'Отменить подготовку фотографий'})).toBeVisible();expect(posts).toBe(1);expect(downloaded).toBe(0);mark('barrier.before.release',{posts,deletes,downloaded});
  const downloadEvent=page.waitForEvent('download');release();
  if(fault==='failed-delete'){await expect(page.getByRole('button',{name:'Повторить скачивание всех фото'})).toBeVisible();expect(posts).toBe(1);expect(downloaded).toBe(0);mark('barrier.failed.DELETE.no.new.POST');await page.getByRole('button',{name:'Повторить скачивание всех фото'}).click();mark('UI.retry.DELETE');}
  const download=await downloadEvent;expect(await download.failure()).toBeNull();await download.saveAs(`${out}/${width}-${fault}.zip`);const entries=archivePhotos(await fs.readFile(`${out}/${width}-${fault}.zip`));expect(entries.map(e=>e.hash).sort()).toEqual([...album.hashes].sort());expect(entries).toHaveLength(3);expect(downloaded).toBe(1);expect(posts).toBe(fault==='lost-ack'?3:2);expect(deletes).toBe(fault==='failed-delete'?2:1);
  if(fault==='lost-ack'){expect(keys[1]).toBe(keys[0]);expect(keys[2]).not.toBe(keys[0]);}else expect(keys[1]).not.toBe(keys[0]);
  const firstDeleteOK=events.findIndex(e=>e.event==='DELETE.server.response'&&e.status===204),freshPost=events.findIndex(e=>e.event==='POST.request'&&e.number===(fault==='lost-ack'?3:2));expect(firstDeleteOK).toBeGreaterThan(-1);expect(firstDeleteOK).toBeLessThan(freshPost);expect((await page.request.get(`${base}/${oldId}`)).status()).toBe(404);
  await expect(page.getByRole('button',{name:'Скачать все фото',exact:true})).toBeVisible();await page.screenshot({path:`${out}/${width}-${fault}-finished.png`});mark('verified.one.browser.ZIP',{photos:3,originalHashes:album.hashes});await download.delete();
 }finally{release();await page.unrouteAll({behavior:'ignoreErrors'});await fs.writeFile(`${out}/${width}-${fault}-events.json`,JSON.stringify({width,fault,meetingId:album.id,oldId,posts,deletes,downloaded,keys,events},null,2));}
});
