import { readFile } from 'node:fs/promises';
import { safePath } from '../design/files.mjs';
import { validate } from './schema.mjs';

// Scope is derived from complete task mappings, never caller-picked check IDs.
export const taskChecks = async (root, plan, manifest, ids) => {
  validate('manifest', manifest);
  if (plan.purpose !== 'feature') throw new Error('Task scope requires feature plan');
  if (!ids.length || new Set(ids).size !== ids.length) throw new Error('Invalid task scope');
  const body = await readFile(await safePath(root, `openspec/changes/${manifest.change}/tasks.md`), 'utf8');
  const declared = new Set([...body.matchAll(/^- \[[ xX]\]\s+(\d+\.\d+)\s/gm)].map((m) => m[1]));
  const required = new Set();
  for (const id of ids) {
    const task = manifest.tasks.find((t) => t.id === id);
    if (!task || !declared.has(id)) throw new Error(`Unknown or exempt task: ${id}`);
    for (const caseId of task.cases) for (const platform of task.platforms) {
      const environments = plan.environments.filter((e) => e.platform === platform);
      if (!plan.selectedCases.includes(caseId) || !environments.length)
        throw new Error(`Incomplete task acceptance scope: ${id}/${caseId}/${platform}`);
      for (const environment of environments) {
        const checks = plan.expected.filter((e) => e.caseId === caseId && e.environment === environment.id);
        if (!checks.length) throw new Error(`Missing task case/platform: ${id}/${caseId}/${platform}`);
        for (const check of checks) required.add(check.id);
      }
    }
  }
  return [...required].sort();
};
