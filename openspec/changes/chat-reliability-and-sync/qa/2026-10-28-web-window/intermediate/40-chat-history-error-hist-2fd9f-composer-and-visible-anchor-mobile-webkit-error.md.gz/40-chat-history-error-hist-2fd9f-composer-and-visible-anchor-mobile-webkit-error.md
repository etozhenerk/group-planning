# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 40-chat-history-error.spec.ts >> history failure remains local and retry preserves composer and visible anchor
- Location: tests/40-chat-history-error.spec.ts:5:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 2
Received:    27
```

# Page snapshot

```yaml
- generic [ref=f3e3]:
  - link "К содержимому" [ref=f3e4]:
    - /url: "#main"
  - generic [ref=f3e5]: Демостенд · данные хранятся до перезапуска
  - main [ref=f3e8]:
    - generic [ref=f3e9]:
      - link "К моим встречам" [ref=f3e10]:
        - /url: /meetings
      - button "Сведения о встрече «Ошибка истории»" [ref=f3e17] [cursor=pointer]:
        - heading "Ошибка истории" [level=1] [ref=f3e18]
        - generic [ref=f3e19]: 24 октября · 19:00 · 1 участник
      - button "Пригласить друзей" [ref=f3e21] [cursor=pointer]
      - button "Информация о встрече" [ref=f3e24] [cursor=pointer]
    - generic [ref=f3e28]:
      - button "Предыдущие записи" [ref=f3e29] [cursor=pointer]
      - list "Разговор встречи" [ref=f3e30]:
        - listitem [ref=f3e32]:
          - generic [aria-hidden] [ref=f3e33]: С
          - generic [ref=f3e34]:
            - generic [ref=f3e35]:
              - strong [ref=f3e36]: Саша
              - time [ref=f3e37]: 00:22
            - 'group "Реакции на сообщение: Запись 39" [ref=f3e38]':
              - paragraph [ref=f3e39]: Запись 39
        - listitem [ref=f3e41]:
          - generic [aria-hidden] [ref=f3e42]: С
          - generic [ref=f3e43]:
            - generic [ref=f3e44]:
              - strong [ref=f3e45]: Саша
              - time [ref=f3e46]: 00:22
            - 'group "Реакции на сообщение: Запись 40" [ref=f3e47]':
              - paragraph [ref=f3e48]: Запись 40
        - listitem [ref=f3e50]:
          - generic [aria-hidden] [ref=f3e51]: С
          - generic [ref=f3e52]:
            - generic [ref=f3e53]:
              - strong [ref=f3e54]: Саша
              - time [ref=f3e55]: 00:22
            - 'group "Реакции на сообщение: Запись 41" [ref=f3e56]':
              - paragraph [ref=f3e57]: Запись 41
        - listitem [ref=f3e59]:
          - generic [aria-hidden] [ref=f3e60]: С
          - generic [ref=f3e61]:
            - generic [ref=f3e62]:
              - strong [ref=f3e63]: Саша
              - time [ref=f3e64]: 00:22
            - 'group "Реакции на сообщение: Запись 42" [ref=f3e65]':
              - paragraph [ref=f3e66]: Запись 42
        - listitem [ref=f3e68]:
          - generic [aria-hidden] [ref=f3e69]: С
          - generic [ref=f3e70]:
            - generic [ref=f3e71]:
              - strong [ref=f3e72]: Саша
              - time [ref=f3e73]: 00:22
            - 'group "Реакции на сообщение: Запись 43" [ref=f3e74]':
              - paragraph [ref=f3e75]: Запись 43
        - listitem [ref=f3e77]:
          - generic [aria-hidden] [ref=f3e78]: С
          - generic [ref=f3e79]:
            - generic [ref=f3e80]:
              - strong [ref=f3e81]: Саша
              - time [ref=f3e82]: 00:22
            - 'group "Реакции на сообщение: Запись 44" [ref=f3e83]':
              - paragraph [ref=f3e84]: Запись 44
        - listitem [ref=f3e86]:
          - generic [aria-hidden] [ref=f3e87]: С
          - generic [ref=f3e88]:
            - generic [ref=f3e89]:
              - strong [ref=f3e90]: Саша
              - time [ref=f3e91]: 00:22
            - 'group "Реакции на сообщение: Запись 45" [ref=f3e92]':
              - paragraph [ref=f3e93]: Запись 45
        - listitem [ref=f3e95]:
          - generic [aria-hidden] [ref=f3e96]: С
          - generic [ref=f3e97]:
            - generic [ref=f3e98]:
              - strong [ref=f3e99]: Саша
              - time [ref=f3e100]: 00:22
            - 'group "Реакции на сообщение: Запись 46" [ref=f3e101]':
              - paragraph [ref=f3e102]: Запись 46
        - listitem [ref=f3e104]:
          - generic [aria-hidden] [ref=f3e105]: С
          - generic [ref=f3e106]:
            - generic [ref=f3e107]:
              - strong [ref=f3e108]: Саша
              - time [ref=f3e109]: 00:22
            - 'group "Реакции на сообщение: Запись 48" [ref=f3e110]':
              - paragraph [ref=f3e111]: Запись 48
        - listitem [ref=f3e113]:
          - generic [aria-hidden] [ref=f3e114]: С
          - generic [ref=f3e115]:
            - generic [ref=f3e116]:
              - strong [ref=f3e117]: Саша
              - time [ref=f3e118]: 00:22
            - 'group "Реакции на сообщение: Запись 47" [ref=f3e119]':
              - paragraph [ref=f3e120]: Запись 47
        - listitem [ref=f3e122]:
          - generic [aria-hidden] [ref=f3e123]: С
          - generic [ref=f3e124]:
            - generic [ref=f3e125]:
              - strong [ref=f3e126]: Саша
              - time [ref=f3e127]: 00:22
            - 'group "Реакции на сообщение: Запись 49" [ref=f3e128]':
              - paragraph [ref=f3e129]: Запись 49
        - listitem [ref=f3e131]:
          - generic [aria-hidden] [ref=f3e132]: С
          - generic [ref=f3e133]:
            - generic [ref=f3e134]:
              - strong [ref=f3e135]: Саша
              - time [ref=f3e136]: 00:22
            - 'group "Реакции на сообщение: Запись 50" [ref=f3e137]':
              - paragraph [ref=f3e138]: Запись 50
        - listitem [ref=f3e140]:
          - generic [aria-hidden] [ref=f3e141]: С
          - generic [ref=f3e142]:
            - generic [ref=f3e143]:
              - strong [ref=f3e144]: Саша
              - time [ref=f3e145]: 00:22
            - 'group "Реакции на сообщение: Запись 51" [ref=f3e146]':
              - paragraph [ref=f3e147]: Запись 51
        - listitem [ref=f3e149]:
          - generic [aria-hidden] [ref=f3e150]: С
          - generic [ref=f3e151]:
            - generic [ref=f3e152]:
              - strong [ref=f3e153]: Саша
              - time [ref=f3e154]: 00:22
            - 'group "Реакции на сообщение: Запись 52" [ref=f3e155]':
              - paragraph [ref=f3e156]: Запись 52
        - listitem [ref=f3e158]:
          - generic [aria-hidden] [ref=f3e159]: С
          - generic [ref=f3e160]:
            - generic [ref=f3e161]:
              - strong [ref=f3e162]: Саша
              - time [ref=f3e163]: 00:22
            - 'group "Реакции на сообщение: Запись 53" [ref=f3e164]':
              - paragraph [ref=f3e165]: Запись 53
        - listitem [ref=f3e167]:
          - generic [aria-hidden] [ref=f3e168]: С
          - generic [ref=f3e169]:
            - generic [ref=f3e170]:
              - strong [ref=f3e171]: Саша
              - time [ref=f3e172]: 00:22
            - 'group "Реакции на сообщение: Запись 54" [ref=f3e173]':
              - paragraph [ref=f3e174]: Запись 54
        - listitem [ref=f3e176]:
          - generic [aria-hidden] [ref=f3e177]: С
          - generic [ref=f3e178]:
            - generic [ref=f3e179]:
              - strong [ref=f3e180]: Саша
              - time [ref=f3e181]: 00:22
            - 'group "Реакции на сообщение: Запись 55" [ref=f3e182]':
              - paragraph [ref=f3e183]: Запись 55
        - listitem [ref=f3e185]:
          - generic [aria-hidden] [ref=f3e186]: С
          - generic [ref=f3e187]:
            - generic [ref=f3e188]:
              - strong [ref=f3e189]: Саша
              - time [ref=f3e190]: 00:22
            - 'group "Реакции на сообщение: Запись 56" [ref=f3e191]':
              - paragraph [ref=f3e192]: Запись 56
        - listitem [ref=f3e194]:
          - generic [aria-hidden] [ref=f3e195]: С
          - generic [ref=f3e196]:
            - generic [ref=f3e197]:
              - strong [ref=f3e198]: Саша
              - time [ref=f3e199]: 00:22
            - 'group "Реакции на сообщение: Запись 57" [ref=f3e200]':
              - paragraph [ref=f3e201]: Запись 57
        - listitem [ref=f3e203]:
          - generic [aria-hidden] [ref=f3e204]: С
          - generic [ref=f3e205]:
            - generic [ref=f3e206]:
              - strong [ref=f3e207]: Саша
              - time [ref=f3e208]: 00:22
            - 'group "Реакции на сообщение: Запись 58" [ref=f3e209]':
              - paragraph [ref=f3e210]: Запись 58
        - listitem [ref=f3e212]:
          - generic [aria-hidden] [ref=f3e213]: С
          - generic [ref=f3e214]:
            - generic [ref=f3e215]:
              - strong [ref=f3e216]: Саша
              - time [ref=f3e217]: 00:22
            - 'group "Реакции на сообщение: Запись 59" [ref=f3e218]':
              - paragraph [ref=f3e219]: Запись 59
        - listitem [ref=f3e221]:
          - generic [aria-hidden] [ref=f3e222]: С
          - generic [ref=f3e223]:
            - generic [ref=f3e224]:
              - strong [ref=f3e225]: Саша
              - time [ref=f3e226]: 00:22
            - 'group "Реакции на сообщение: Запись 60" [ref=f3e227]':
              - paragraph [ref=f3e228]: Запись 60
        - listitem [ref=f3e230]:
          - generic [aria-hidden] [ref=f3e231]: С
          - generic [ref=f3e232]:
            - generic [ref=f3e233]:
              - strong [ref=f3e234]: Саша
              - time [ref=f3e235]: 00:22
            - 'group "Реакции на сообщение: Запись 61" [ref=f3e236]':
              - paragraph [ref=f3e237]: Запись 61
        - listitem [ref=f3e239]:
          - generic [aria-hidden] [ref=f3e240]: С
          - generic [ref=f3e241]:
            - generic [ref=f3e242]:
              - strong [ref=f3e243]: Саша
              - time [ref=f3e244]: 00:22
            - 'group "Реакции на сообщение: Запись 62" [ref=f3e245]':
              - paragraph [ref=f3e246]: Запись 62
        - listitem [ref=f3e248]:
          - generic [aria-hidden] [ref=f3e249]: С
          - generic [ref=f3e250]:
            - generic [ref=f3e251]:
              - strong [ref=f3e252]: Саша
              - time [ref=f3e253]: 00:22
            - 'group "Реакции на сообщение: Запись 63" [ref=f3e254]':
              - paragraph [ref=f3e255]: Запись 63
        - listitem [ref=f3e257]:
          - generic [aria-hidden] [ref=f3e258]: С
          - generic [ref=f3e259]:
            - generic [ref=f3e260]:
              - strong [ref=f3e261]: Саша
              - time [ref=f3e262]: 00:22
            - 'group "Реакции на сообщение: Запись 64" [ref=f3e263]':
              - paragraph [ref=f3e264]: Запись 64
        - listitem [ref=f3e266]:
          - generic [aria-hidden] [ref=f3e267]: С
          - generic [ref=f3e268]:
            - generic [ref=f3e269]:
              - strong [ref=f3e270]: Саша
              - time [ref=f3e271]: 00:22
            - 'group "Реакции на сообщение: Запись 65" [ref=f3e272]':
              - paragraph [ref=f3e273]: Запись 65
        - listitem [ref=f3e275]:
          - generic [aria-hidden] [ref=f3e276]: С
          - generic [ref=f3e277]:
            - generic [ref=f3e278]:
              - strong [ref=f3e279]: Саша
              - time [ref=f3e280]: 00:22
            - 'group "Реакции на сообщение: Запись 66" [ref=f3e281]':
              - paragraph [ref=f3e282]: Запись 66
        - listitem [ref=f3e284]:
          - generic [aria-hidden] [ref=f3e285]: С
          - generic [ref=f3e286]:
            - generic [ref=f3e287]:
              - strong [ref=f3e288]: Саша
              - time [ref=f3e289]: 00:22
            - 'group "Реакции на сообщение: Запись 67" [ref=f3e290]':
              - paragraph [ref=f3e291]: Запись 67
    - generic [ref=f3e294]:
      - button "Добавить к встрече" [ref=f3e296] [cursor=pointer]
      - generic [ref=f3e299]:
        - generic [ref=f3e300]:
          - generic [ref=f3e301]: Сообщение
          - textbox "Сообщение" [ref=f3e302]:
            - /placeholder: Сообщение…
            - text: Черновик остаётся
        - button "Выбрать эмодзи" [ref=f3e303] [cursor=pointer]
      - button "Отправить сообщение" [ref=f3e309] [cursor=pointer]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import { randomUUID } from 'node:crypto';
  3  | import { apiCreate, login, writeHeaders } from '@tests/helpers';
  4  | 
  5  | test('history failure remains local and retry preserves composer and visible anchor', async ({
  6  |   page,
  7  | }) => {
  8  |   await login(page, 'Саша');
  9  |   const { meeting } = await apiCreate(page, 'Ошибка истории');
  10 |   const headers = await writeHeaders(page);
  11 | 
  12 |   for (let batch = 0; batch < 10; batch += 1) {
  13 |     await Promise.all(
  14 |       Array.from({ length: 10 }, (_, index) => {
  15 |         const key = randomUUID();
  16 | 
  17 |         return page.request.post(`/api/v1/meetings/${meeting.id}/messages`, {
  18 |           headers: { ...headers, 'Idempotency-Key': key },
  19 |           data: { text: `Запись ${batch * 10 + index}`, client_request_id: key },
  20 |         });
  21 |       }),
  22 |     );
  23 |   }
  24 | 
  25 |   await page.goto(`/meetings/${meeting.id}`);
  26 |   const scroll = page.locator('[data-server-count]');
  27 |   const composer = page.getByLabel('Сообщение', { exact: true });
  28 |   await expect(scroll).toBeVisible();
  29 |   await composer.fill('Черновик остаётся');
  30 |   await page.route(
  31 |     `**/meetings/${meeting.id}/feed?*before_sequence=*`,
  32 |     (route) =>
  33 |       route.fulfill({
  34 |         status: 503,
  35 |         json: {
  36 |           error: { code: 'unavailable', field_errors: {}, request_id: 'history-failure' },
  37 |         },
  38 |       }),
  39 |     { times: 1 },
  40 |   );
  41 |   await scroll.evaluate((element) => {
  42 |     element.scrollTop = 1;
  43 |   });
  44 |   await expect(page.getByRole('alert')).toContainText('Не удалось загрузить сообщения');
  45 |   await expect(composer).toHaveValue('Черновик остаётся');
  46 |   await expect(composer).toBeEditable();
  47 |   const capture = () =>
  48 |     scroll.evaluate((element) => {
  49 |       const top = element.getBoundingClientRect().top;
  50 |       const row = [...element.querySelectorAll<HTMLElement>('[data-entry-id]')].find(
  51 |         (row) =>
  52 |           row.dataset.protected !== 'true' && row.getBoundingClientRect().bottom > top,
  53 |       );
  54 | 
  55 |       return {
  56 |         id: row?.dataset.entryId,
  57 |         offset: (row?.getBoundingClientRect().top ?? top) - top,
  58 |       };
  59 |     });
  60 | 
  61 |   const before = await capture();
  62 |   const first = await scroll.getAttribute('data-window-first');
  63 |   await page
  64 |     .getByRole('alert')
  65 |     .getByRole('button', { name: 'Повторить', exact: true })
  66 |     .click();
  67 |   await expect.poll(() => scroll.getAttribute('data-window-first')).not.toBe(first);
  68 |   await expect(page.getByRole('alert')).toHaveCount(0);
  69 |   const after = await scroll.evaluate((element, id) => {
  70 |     const row = element.querySelector<HTMLElement>(
  71 |       `[data-entry-id="${CSS.escape(id ?? '')}"]`,
  72 |     );
  73 | 
  74 |     return {
  75 |       id: row?.dataset.entryId,
  76 |       offset:
  77 |         (row?.getBoundingClientRect().top ?? 0) - element.getBoundingClientRect().top,
  78 |     };
  79 |   }, before.id);
  80 | 
  81 |   expect(after.id).toBe(before.id);
> 82 |   expect(Math.abs(after.offset - before.offset)).toBeLessThanOrEqual(2);
     |                                                  ^ Error: expect(received).toBeLessThanOrEqual(expected)
  83 |   await expect(composer).toHaveValue('Черновик остаётся');
  84 |   await test.info().attach('history-retry-anchor', {
  85 |     body: JSON.stringify({ before, after }),
  86 |     contentType: 'application/json',
  87 |   });
  88 | });
  89 | 
```