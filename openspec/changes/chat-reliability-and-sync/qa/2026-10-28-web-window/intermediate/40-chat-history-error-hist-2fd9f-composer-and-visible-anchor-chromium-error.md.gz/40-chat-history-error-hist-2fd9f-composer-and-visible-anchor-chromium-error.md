# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 40-chat-history-error.spec.ts >> history failure remains local and retry preserves composer and visible anchor
- Location: tests/40-chat-history-error.spec.ts:5:1

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 2
Received:    23.703125
```

# Page snapshot

```yaml
- generic [ref=f3e3]:
  - link "К содержимому" [ref=f3e4] [cursor=pointer]:
    - /url: "#main"
  - generic [ref=f3e5]: Демостенд · данные хранятся до перезапуска
  - generic [ref=f3e6]:
    - navigation "Основная навигация" [ref=f3e8]:
      - link "Somewhere — на главную" [ref=f3e10] [cursor=pointer]:
        - /url: /
        - generic [ref=f3e11]: somewhere
      - generic [ref=f3e12]:
        - link "Встречи" [ref=f3e13] [cursor=pointer]:
          - /url: /meetings
          - generic [ref=f3e16]: Мои встречи
        - link "Приглашения" [ref=f3e17] [cursor=pointer]:
          - /url: /invitations
        - link "Сообщить о проблеме" [ref=f3e22] [cursor=pointer]:
          - /url: /support
        - link "Профиль" [ref=f3e26] [cursor=pointer]:
          - /url: /profile
          - generic [aria-hidden] [ref=f3e28]: С
          - generic [ref=f3e29]:
            - strong [ref=f3e30]: Саша
            - generic [ref=f3e31]: Мой профиль
    - generic [ref=f3e32]:
      - main [ref=f3e33]:
        - generic [ref=f3e34]:
          - link "К моим встречам" [ref=f3e35] [cursor=pointer]:
            - /url: /meetings
          - generic [ref=f3e38]:
            - heading "Ошибка истории" [level=1] [ref=f3e39]
            - paragraph [ref=f3e40]: 1 участник · 24 октября · 19:00
          - button "Пригласить друзей" [ref=f3e42] [cursor=pointer]
          - button "Информация о встрече" [ref=f3e45] [cursor=pointer]
        - generic [ref=f3e50]:
          - button "Предыдущие записи" [ref=f3e51] [cursor=pointer]
          - list "Разговор встречи" [ref=f3e52]:
            - listitem [ref=f3e54]:
              - generic [aria-hidden] [ref=f3e55]: С
              - generic [ref=f3e56]:
                - generic [ref=f3e57]:
                  - strong [ref=f3e58]: Саша
                  - time [ref=f3e59]: 00:22
                - 'group "Реакции на сообщение: Запись 39" [ref=f3e60]':
                  - paragraph [ref=f3e61]: Запись 39
            - listitem [ref=f3e63]:
              - generic [aria-hidden] [ref=f3e64]: С
              - generic [ref=f3e65]:
                - generic [ref=f3e66]:
                  - strong [ref=f3e67]: Саша
                  - time [ref=f3e68]: 00:22
                - 'group "Реакции на сообщение: Запись 40" [ref=f3e69]':
                  - paragraph [ref=f3e70]: Запись 40
            - listitem [ref=f3e72]:
              - generic [aria-hidden] [ref=f3e73]: С
              - generic [ref=f3e74]:
                - generic [ref=f3e75]:
                  - strong [ref=f3e76]: Саша
                  - time [ref=f3e77]: 00:22
                - 'group "Реакции на сообщение: Запись 41" [ref=f3e78]':
                  - paragraph [ref=f3e79]: Запись 41
            - listitem [ref=f3e81]:
              - generic [aria-hidden] [ref=f3e82]: С
              - generic [ref=f3e83]:
                - generic [ref=f3e84]:
                  - strong [ref=f3e85]: Саша
                  - time [ref=f3e86]: 00:22
                - 'group "Реакции на сообщение: Запись 42" [ref=f3e87]':
                  - paragraph [ref=f3e88]: Запись 42
            - listitem [ref=f3e90]:
              - generic [aria-hidden] [ref=f3e91]: С
              - generic [ref=f3e92]:
                - generic [ref=f3e93]:
                  - strong [ref=f3e94]: Саша
                  - time [ref=f3e95]: 00:22
                - 'group "Реакции на сообщение: Запись 43" [ref=f3e96]':
                  - paragraph [ref=f3e97]: Запись 43
            - listitem [ref=f3e99]:
              - generic [aria-hidden] [ref=f3e100]: С
              - generic [ref=f3e101]:
                - generic [ref=f3e102]:
                  - strong [ref=f3e103]: Саша
                  - time [ref=f3e104]: 00:22
                - 'group "Реакции на сообщение: Запись 44" [ref=f3e105]':
                  - paragraph [ref=f3e106]: Запись 44
            - listitem [ref=f3e108]:
              - generic [aria-hidden] [ref=f3e109]: С
              - generic [ref=f3e110]:
                - generic [ref=f3e111]:
                  - strong [ref=f3e112]: Саша
                  - time [ref=f3e113]: 00:22
                - 'group "Реакции на сообщение: Запись 45" [ref=f3e114]':
                  - paragraph [ref=f3e115]: Запись 45
            - listitem [ref=f3e117]:
              - generic [aria-hidden] [ref=f3e118]: С
              - generic [ref=f3e119]:
                - generic [ref=f3e120]:
                  - strong [ref=f3e121]: Саша
                  - time [ref=f3e122]: 00:22
                - 'group "Реакции на сообщение: Запись 46" [ref=f3e123]':
                  - paragraph [ref=f3e124]: Запись 46
            - listitem [ref=f3e126]:
              - generic [aria-hidden] [ref=f3e127]: С
              - generic [ref=f3e128]:
                - generic [ref=f3e129]:
                  - strong [ref=f3e130]: Саша
                  - time [ref=f3e131]: 00:22
                - 'group "Реакции на сообщение: Запись 47" [ref=f3e132]':
                  - paragraph [ref=f3e133]: Запись 47
            - listitem [ref=f3e135]:
              - generic [aria-hidden] [ref=f3e136]: С
              - generic [ref=f3e137]:
                - generic [ref=f3e138]:
                  - strong [ref=f3e139]: Саша
                  - time [ref=f3e140]: 00:22
                - 'group "Реакции на сообщение: Запись 48" [ref=f3e141]':
                  - paragraph [ref=f3e142]: Запись 48
            - listitem [ref=f3e144]:
              - generic [aria-hidden] [ref=f3e145]: С
              - generic [ref=f3e146]:
                - generic [ref=f3e147]:
                  - strong [ref=f3e148]: Саша
                  - time [ref=f3e149]: 00:22
                - 'group "Реакции на сообщение: Запись 49" [ref=f3e150]':
                  - paragraph [ref=f3e151]: Запись 49
            - listitem [ref=f3e153]:
              - generic [aria-hidden] [ref=f3e154]: С
              - generic [ref=f3e155]:
                - generic [ref=f3e156]:
                  - strong [ref=f3e157]: Саша
                  - time [ref=f3e158]: 00:22
                - 'group "Реакции на сообщение: Запись 50" [ref=f3e159]':
                  - paragraph [ref=f3e160]: Запись 50
            - listitem [ref=f3e162]:
              - generic [aria-hidden] [ref=f3e163]: С
              - generic [ref=f3e164]:
                - generic [ref=f3e165]:
                  - strong [ref=f3e166]: Саша
                  - time [ref=f3e167]: 00:22
                - 'group "Реакции на сообщение: Запись 51" [ref=f3e168]':
                  - paragraph [ref=f3e169]: Запись 51
            - listitem [ref=f3e171]:
              - generic [aria-hidden] [ref=f3e172]: С
              - generic [ref=f3e173]:
                - generic [ref=f3e174]:
                  - strong [ref=f3e175]: Саша
                  - time [ref=f3e176]: 00:22
                - 'group "Реакции на сообщение: Запись 52" [ref=f3e177]':
                  - paragraph [ref=f3e178]: Запись 52
            - listitem [ref=f3e180]:
              - generic [aria-hidden] [ref=f3e181]: С
              - generic [ref=f3e182]:
                - generic [ref=f3e183]:
                  - strong [ref=f3e184]: Саша
                  - time [ref=f3e185]: 00:22
                - 'group "Реакции на сообщение: Запись 53" [ref=f3e186]':
                  - paragraph [ref=f3e187]: Запись 53
            - listitem [ref=f3e189]:
              - generic [aria-hidden] [ref=f3e190]: С
              - generic [ref=f3e191]:
                - generic [ref=f3e192]:
                  - strong [ref=f3e193]: Саша
                  - time [ref=f3e194]: 00:22
                - 'group "Реакции на сообщение: Запись 54" [ref=f3e195]':
                  - paragraph [ref=f3e196]: Запись 54
            - listitem [ref=f3e198]:
              - generic [aria-hidden] [ref=f3e199]: С
              - generic [ref=f3e200]:
                - generic [ref=f3e201]:
                  - strong [ref=f3e202]: Саша
                  - time [ref=f3e203]: 00:22
                - 'group "Реакции на сообщение: Запись 55" [ref=f3e204]':
                  - paragraph [ref=f3e205]: Запись 55
            - listitem [ref=f3e207]:
              - generic [aria-hidden] [ref=f3e208]: С
              - generic [ref=f3e209]:
                - generic [ref=f3e210]:
                  - strong [ref=f3e211]: Саша
                  - time [ref=f3e212]: 00:22
                - 'group "Реакции на сообщение: Запись 56" [ref=f3e213]':
                  - paragraph [ref=f3e214]: Запись 56
            - listitem [ref=f3e216]:
              - generic [aria-hidden] [ref=f3e217]: С
              - generic [ref=f3e218]:
                - generic [ref=f3e219]:
                  - strong [ref=f3e220]: Саша
                  - time [ref=f3e221]: 00:22
                - 'group "Реакции на сообщение: Запись 57" [ref=f3e222]':
                  - paragraph [ref=f3e223]: Запись 57
            - listitem [ref=f3e225]:
              - generic [aria-hidden] [ref=f3e226]: С
              - generic [ref=f3e227]:
                - generic [ref=f3e228]:
                  - strong [ref=f3e229]: Саша
                  - time [ref=f3e230]: 00:22
                - 'group "Реакции на сообщение: Запись 58" [ref=f3e231]':
                  - paragraph [ref=f3e232]: Запись 58
            - listitem [ref=f3e234]:
              - generic [aria-hidden] [ref=f3e235]: С
              - generic [ref=f3e236]:
                - generic [ref=f3e237]:
                  - strong [ref=f3e238]: Саша
                  - time [ref=f3e239]: 00:22
                - 'group "Реакции на сообщение: Запись 59" [ref=f3e240]':
                  - paragraph [ref=f3e241]: Запись 59
            - listitem [ref=f3e243]:
              - generic [aria-hidden] [ref=f3e244]: С
              - generic [ref=f3e245]:
                - generic [ref=f3e246]:
                  - strong [ref=f3e247]: Саша
                  - time [ref=f3e248]: 00:22
                - 'group "Реакции на сообщение: Запись 60" [ref=f3e249]':
                  - paragraph [ref=f3e250]: Запись 60
            - listitem [ref=f3e252]:
              - generic [aria-hidden] [ref=f3e253]: С
              - generic [ref=f3e254]:
                - generic [ref=f3e255]:
                  - strong [ref=f3e256]: Саша
                  - time [ref=f3e257]: 00:22
                - 'group "Реакции на сообщение: Запись 61" [ref=f3e258]':
                  - paragraph [ref=f3e259]: Запись 61
            - listitem [ref=f3e261]:
              - generic [aria-hidden] [ref=f3e262]: С
              - generic [ref=f3e263]:
                - generic [ref=f3e264]:
                  - strong [ref=f3e265]: Саша
                  - time [ref=f3e266]: 00:22
                - 'group "Реакции на сообщение: Запись 62" [ref=f3e267]':
                  - paragraph [ref=f3e268]: Запись 62
            - listitem [ref=f3e270]:
              - generic [aria-hidden] [ref=f3e271]: С
              - generic [ref=f3e272]:
                - generic [ref=f3e273]:
                  - strong [ref=f3e274]: Саша
                  - time [ref=f3e275]: 00:22
                - 'group "Реакции на сообщение: Запись 63" [ref=f3e276]':
                  - paragraph [ref=f3e277]: Запись 63
            - listitem [ref=f3e279]:
              - generic [aria-hidden] [ref=f3e280]: С
              - generic [ref=f3e281]:
                - generic [ref=f3e282]:
                  - strong [ref=f3e283]: Саша
                  - time [ref=f3e284]: 00:22
                - 'group "Реакции на сообщение: Запись 64" [ref=f3e285]':
                  - paragraph [ref=f3e286]: Запись 64
            - listitem [ref=f3e288]:
              - generic [aria-hidden] [ref=f3e289]: С
              - generic [ref=f3e290]:
                - generic [ref=f3e291]:
                  - strong [ref=f3e292]: Саша
                  - time [ref=f3e293]: 00:22
                - 'group "Реакции на сообщение: Запись 65" [ref=f3e294]':
                  - paragraph [ref=f3e295]: Запись 65
        - generic [ref=f3e298]:
          - button "Добавить к встрече" [ref=f3e300] [cursor=pointer]
          - generic [ref=f3e303]:
            - generic [ref=f3e304]:
              - generic [ref=f3e305]: Сообщение
              - textbox "Сообщение" [ref=f3e306]:
                - /placeholder: Сообщение…
                - text: Черновик остаётся
            - button "Выбрать эмодзи" [ref=f3e307] [cursor=pointer]
          - button "Отправить сообщение" [ref=f3e313] [cursor=pointer]
      - complementary [ref=f3e316]:
        - generic [ref=f3e317]:
          - generic [ref=f3e318]:
            - generic [ref=f3e319]:
              - term [ref=f3e320]: Когда
              - definition [ref=f3e321]:
                - generic [ref=f3e322]: 24 октября в 19:00
                - generic [ref=f3e323]: Москва
            - generic [ref=f3e324]:
              - term [ref=f3e325]: Где
              - definition [ref=f3e326]: Место пока не выбрано
          - generic [ref=f3e327]:
            - heading "Кто придёт · 1" [level=3] [ref=f3e328]
            - 'button "Все участники встречи. Придут: 1" [ref=f3e329] [cursor=pointer]':
              - generic "Саша" [ref=f3e330]:
                - generic [aria-hidden] [ref=f3e331]: С
                - text: Саша
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import { randomUUID } from 'node:crypto';
  3  | import { apiCreate, login, writeHeaders } from '@tests/helpers';
  4  | 
  5  | test('history failure remains local and retry preserves composer and visible anchor', async ({
  6  |   page,
  7  | }) => {
  8  |   await login(page, 'Саша');
  9  |   const { meeting } = await apiCreate(page, 'Ошибка истории');
  10 |   const headers = await writeHeaders(page);
  11 | 
  12 |   for (let batch = 0; batch < 10; batch += 1) {
  13 |     await Promise.all(
  14 |       Array.from({ length: 10 }, (_, index) => {
  15 |         const key = randomUUID();
  16 | 
  17 |         return page.request.post(`/api/v1/meetings/${meeting.id}/messages`, {
  18 |           headers: { ...headers, 'Idempotency-Key': key },
  19 |           data: { text: `Запись ${batch * 10 + index}`, client_request_id: key },
  20 |         });
  21 |       }),
  22 |     );
  23 |   }
  24 | 
  25 |   await page.goto(`/meetings/${meeting.id}`);
  26 |   const scroll = page.locator('[data-server-count]');
  27 |   const composer = page.getByLabel('Сообщение', { exact: true });
  28 |   await expect(scroll).toBeVisible();
  29 |   await composer.fill('Черновик остаётся');
  30 |   await page.route(
  31 |     `**/meetings/${meeting.id}/feed?*before_sequence=*`,
  32 |     (route) =>
  33 |       route.fulfill({
  34 |         status: 503,
  35 |         json: {
  36 |           error: { code: 'unavailable', field_errors: {}, request_id: 'history-failure' },
  37 |         },
  38 |       }),
  39 |     { times: 1 },
  40 |   );
  41 |   await scroll.evaluate((element) => {
  42 |     element.scrollTop = 1;
  43 |   });
  44 |   await expect(page.getByRole('alert')).toContainText('Не удалось загрузить сообщения');
  45 |   await expect(composer).toHaveValue('Черновик остаётся');
  46 |   await expect(composer).toBeEditable();
  47 |   const capture = () =>
  48 |     scroll.evaluate((element) => {
  49 |       const top = element.getBoundingClientRect().top;
  50 |       const row = [...element.querySelectorAll<HTMLElement>('[data-entry-id]')].find(
  51 |         (row) =>
  52 |           row.dataset.protected !== 'true' && row.getBoundingClientRect().bottom > top,
  53 |       );
  54 | 
  55 |       return {
  56 |         id: row?.dataset.entryId,
  57 |         offset: (row?.getBoundingClientRect().top ?? top) - top,
  58 |       };
  59 |     });
  60 | 
  61 |   const before = await capture();
  62 |   const first = await scroll.getAttribute('data-window-first');
  63 |   await page
  64 |     .getByRole('alert')
  65 |     .getByRole('button', { name: 'Повторить', exact: true })
  66 |     .click();
  67 |   await expect.poll(() => scroll.getAttribute('data-window-first')).not.toBe(first);
  68 |   await expect(page.getByRole('alert')).toHaveCount(0);
  69 |   const after = await scroll.evaluate((element, id) => {
  70 |     const row = element.querySelector<HTMLElement>(
  71 |       `[data-entry-id="${CSS.escape(id ?? '')}"]`,
  72 |     );
  73 | 
  74 |     return {
  75 |       id: row?.dataset.entryId,
  76 |       offset:
  77 |         (row?.getBoundingClientRect().top ?? 0) - element.getBoundingClientRect().top,
  78 |     };
  79 |   }, before.id);
  80 | 
  81 |   expect(after.id).toBe(before.id);
> 82 |   expect(Math.abs(after.offset - before.offset)).toBeLessThanOrEqual(2);
     |                                                  ^ Error: expect(received).toBeLessThanOrEqual(expected)
  83 |   await expect(composer).toHaveValue('Черновик остаётся');
  84 |   await test.info().attach('history-retry-anchor', {
  85 |     body: JSON.stringify({ before, after }),
  86 |     contentType: 'application/json',
  87 |   });
  88 | });
  89 | 
```