import {afterEach,expect,it,vi} from 'vitest';
import {writeFile} from 'node:fs/promises';
import {createChatUpdates} from '/Users/misha/Documents/Codex/projects/group-planning/frontend/web/src/entities/meeting/model/createChatUpdates';
afterEach(()=>vi.useRealTimers());
const out='/tmp/somewhere-web-sdd-independent/final/chat-residual/evidence';
it('healthy90s and repeated hints remain serial and catch up latest state',async()=>{
 vi.useFakeTimers();vi.setSystemTime(0);let callbacks:any,calls=0,inflight=0,max=0,latest=0,applied=0,resolve:undefined|(()=>void);
 const owner=createChatUpdates({realtime:true,random:()=>0.5,authenticate:async()=>{},terminal:()=>false,connect:e=>{callbacks=e;return()=>{};},refresh:async()=>{calls++;inflight++;max=Math.max(max,inflight);if(calls===2)await new Promise<void>(r=>resolve=r);applied=latest;inflight--;}});
 try{await vi.advanceTimersByTimeAsync(0);callbacks.ready();await vi.advanceTimersByTimeAsync(90000);expect(calls).toBe(1);latest=1;callbacks.hint();await vi.advanceTimersByTimeAsync(100);expect(calls).toBe(2);for(let i=0;i<20;i++){latest=Math.max(latest,20-i);callbacks.hint();}await vi.advanceTimersByTimeAsync(100);expect(calls).toBe(2);resolve!();await vi.advanceTimersByTimeAsync(0);expect(calls).toBe(3);expect(applied).toBe(20);expect(max).toBe(1);await vi.advanceTimersByTimeAsync(90000);expect(calls).toBe(3);await writeFile(out+'/healthy-burst-timer.json',JSON.stringify({idleMs:180000,coalescedBurstHints:20,maxInFlight:max,calls,latestApplied:applied}));}finally{owner.stop();}
});
for(const httpFails of [false,true])it(`protocol90 fallback3-6-12-30 when HTTP ${httpFails?'fails':'works'}`,async()=>{
 vi.useFakeTimers();vi.setSystemTime(0);const calls:number[]=[];const owner=createChatUpdates({realtime:true,random:()=>0.5,authenticate:async()=>{},terminal:()=>false,connect:()=>()=>{},refresh:async()=>{calls.push(Date.now());if(httpFails)throw Error('controlled HTTP failure');}});
 try{await vi.advanceTimersByTimeAsync(100000);const actual=calls.slice(0,5),gaps=actual.map((x,i)=>x-(i?actual[i-1]:10000));await writeFile(`${out}/fallback-${httpFails?'http-error':'http-working'}.json`,JSON.stringify({jitterRandom:0.5,realtimeStableFailure:true,httpFails,graceMs:10000,actualCallTimes:actual,actualGaps:gaps,expectedFirstFourCallTimes:[13000,19000,31000,61000]},null,2));expect(calls.slice(0,4)).toEqual([13000,19000,31000,61000]);}finally{owner.stop();}
});
