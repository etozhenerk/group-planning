# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 07-share-preview.spec.ts >> short invitation provides fresh metadata and PNG without JavaScript
- Location: tests/07-share-preview.spec.ts:4:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "https://127.0.0.1:8444/share-card.png"
Received: "https://127.0.0.1:8458/share-card.png"
```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - link "К содержимому" [ref=f2e4] [cursor=pointer]:
    - /url: "#main"
  - generic [ref=f2e5]: Демостенд · данные хранятся до перезапуска
  - generic [ref=f2e6]:
    - navigation "Основная навигация" [ref=f2e8]:
      - link "Somewhere — на главную" [ref=f2e10] [cursor=pointer]:
        - /url: /
        - generic [ref=f2e11]: somewhere
      - generic [ref=f2e12]:
        - link "Встречи" [ref=f2e13] [cursor=pointer]:
          - /url: /meetings
          - generic [ref=f2e16]: Мои встречи
        - link "Приглашения" [ref=f2e17] [cursor=pointer]:
          - /url: /invitations
        - link "Сообщить о проблеме" [ref=f2e22] [cursor=pointer]:
          - /url: /support
        - link "Профиль" [ref=f2e26] [cursor=pointer]:
          - /url: /profile
          - generic [aria-hidden] [ref=f2e28]: С
          - generic [ref=f2e29]:
            - strong [ref=f2e30]: Саша
            - generic [ref=f2e31]: Мой профиль
    - main [active] [ref=f2e33]:
      - generic [ref=f2e35]:
        - heading "Мои встречи" [level=1] [ref=f2e36]
        - link "Создать встречу" [ref=f2e37] [cursor=pointer]:
          - /url: /meetings/new
          - text: Создать
      - generic [ref=f2e39]:
        - navigation "Период встреч" [ref=f2e40]:
          - button "Предстоящие 17" [pressed] [ref=f2e41] [cursor=pointer]:
            - text: Предстоящие
            - generic [ref=f2e42]: "17"
          - button "Прошедшие 2" [ref=f2e43] [cursor=pointer]:
            - text: Прошедшие
            - generic [ref=f2e44]: "2"
        - navigation "Вид встреч" [ref=f2e45]:
          - button "Список" [pressed] [ref=f2e46] [cursor=pointer]
          - button "Календарь" [ref=f2e48] [cursor=pointer]
      - generic [ref=f2e52]:
        - generic [ref=f2e53]:
          - heading "ноябрь 2026" [level=2] [ref=f2e54]
          - generic [ref=f2e55]:
            - article [ref=f2e56]:
              - link [ref=f2e57] [cursor=pointer]:
                - /url: /meetings/900d07eb-8db7-4394-b15f-4be07c31b319
                - time [ref=f2e58]: Вс, 1 ноября · 01:30
                - generic [ref=f2e59]:
                  - heading "Повторяющийся час Вы организатор" [level=2] [ref=f2e61]:
                    - text: Повторяющийся
                    - generic [ref=f2e62]:
                      - generic [ref=f2e63]: час
                      - img "Вы организатор" [ref=f2e64]
                  - paragraph [ref=f2e66]: Место пока не выбрано
                  - paragraph [ref=f2e70]: Восточная Америка
                - 'generic "Участников: 1" [ref=f2e74]':
                  - generic "Саша · Организатор" [ref=f2e75]:
                    - generic [aria-hidden] [ref=f2e76]: С
            - article [ref=f2e77]:
              - link [ref=f2e78] [cursor=pointer]:
                - /url: /meetings/cd82c43a-23de-4159-b445-3cf5b7d001a1
                - time [ref=f2e79]: Вс, 1 ноября · 01:30
                - generic [ref=f2e80]:
                  - heading "Точное время Вы организатор" [level=2] [ref=f2e82]:
                    - text: Точное
                    - generic [ref=f2e83]:
                      - generic [ref=f2e84]: время
                      - img "Вы организатор" [ref=f2e85]
                  - paragraph [ref=f2e87]: Место пока не выбрано
                  - paragraph [ref=f2e91]: Восточная Америка
                - 'generic "Участников: 1" [ref=f2e95]':
                  - generic "Саша · Организатор" [ref=f2e96]:
                    - generic [aria-hidden] [ref=f2e97]: С
        - generic [ref=f2e98]:
          - heading "октябрь 2099" [level=2] [ref=f2e99]
          - generic [ref=f2e100]:
            - article [ref=f2e101]:
              - link [ref=f2e102] [cursor=pointer]:
                - /url: /meetings/03924827-5b2a-42ca-98f6-6ca9abacac0f
                - time [ref=f2e103]: Сб, 24 октября · 19:00
                - generic [ref=f2e104]:
                  - heading "Раскладка 1440 Вы организатор" [level=2] [ref=f2e106]:
                    - text: Раскладка
                    - generic [ref=f2e107]:
                      - generic [ref=f2e108]: "1440"
                      - img "Вы организатор" [ref=f2e109]
                  - paragraph [ref=f2e111]: Место пока не выбрано
                - 'generic "Участников: 1" [ref=f2e118]':
                  - generic "Саша · Организатор" [ref=f2e119]:
                    - generic [aria-hidden] [ref=f2e120]: С
            - article [ref=f2e121]:
              - link [ref=f2e122] [cursor=pointer]:
                - /url: /meetings/0a2d9000-232e-4b49-aa57-b5a4c3f75135
                - time [ref=f2e123]: Сб, 24 октября · 19:00
                - generic [ref=f2e124]:
                  - heading "Единственное действие 320 Вы организатор" [level=2] [ref=f2e126]:
                    - text: Единственное действие
                    - generic [ref=f2e127]:
                      - generic [ref=f2e128]: "320"
                      - img "Вы организатор" [ref=f2e129]
                  - paragraph [ref=f2e131]: Место пока не выбрано
                - 'generic "Участников: 1" [ref=f2e138]':
                  - generic "Саша · Организатор" [ref=f2e139]:
                    - generic [aria-hidden] [ref=f2e140]: С
            - article [ref=f2e141]:
              - link [ref=f2e142] [cursor=pointer]:
                - /url: /meetings/47a819e2-af20-4a46-8ee9-d32ebc76062c
                - time [ref=f2e143]: Сб, 24 октября · 19:00
                - generic [ref=f2e144]:
                  - heading "Детали без повторов Вы организатор" [level=2] [ref=f2e146]:
                    - text: Детали без
                    - generic [ref=f2e147]:
                      - generic [ref=f2e148]: повторов
                      - img "Вы организатор" [ref=f2e149]
                  - paragraph [ref=f2e151]: Место пока не выбрано
                - 'generic "Участников: 1" [ref=f2e158]':
                  - generic "Саша · Организатор" [ref=f2e159]:
                    - generic [aria-hidden] [ref=f2e160]: С
            - article [ref=f2e161]:
              - link [ref=f2e162] [cursor=pointer]:
                - /url: /meetings/47b34a39-381b-4df9-a27a-cadbcf6ae5fc
                - time [ref=f2e163]: Сб, 24 октября · 19:00
                - generic [ref=f2e164]:
                  - heading "Отозванный доступ Вы организатор" [level=2] [ref=f2e166]:
                    - text: Отозванный
                    - generic [ref=f2e167]:
                      - generic [ref=f2e168]: доступ
                      - img "Вы организатор" [ref=f2e169]
                  - paragraph [ref=f2e171]: Место пока не выбрано
                - 'generic "Участников: 2" [ref=f2e178]':
                  - generic "Саша · Организатор" [ref=f2e179]:
                    - generic [aria-hidden] [ref=f2e180]: С
                  - generic "Лена" [ref=f2e181]:
                    - generic [aria-hidden] [ref=f2e182]: Л
            - article [ref=f2e183]:
              - link [ref=f2e184] [cursor=pointer]:
                - /url: /meetings/6811b074-7921-498b-9cf0-f6c5000f3306
                - time [ref=f2e185]: Сб, 24 октября · 19:00
                - generic [ref=f2e186]:
                  - heading "Раскладка 768 Вы организатор" [level=2] [ref=f2e188]:
                    - text: Раскладка
                    - generic [ref=f2e189]:
                      - generic [ref=f2e190]: "768"
                      - img "Вы организатор" [ref=f2e191]
                  - paragraph [ref=f2e193]: Место пока не выбрано
                - 'generic "Участников: 1" [ref=f2e200]':
                  - generic "Саша · Организатор" [ref=f2e201]:
                    - generic [aria-hidden] [ref=f2e202]: С
            - article [ref=f2e203]:
              - link [ref=f2e204] [cursor=pointer]:
                - /url: /meetings/697134e2-9df3-4eed-a0e8-ef8c505dedad
                - time [ref=f2e205]: Сб, 24 октября · 19:00
                - generic [ref=f2e206]:
                  - heading "Отмена входа Вы организатор" [level=2] [ref=f2e208]:
                    - text: Отмена
                    - generic [ref=f2e209]:
                      - generic [ref=f2e210]: входа
                      - img "Вы организатор" [ref=f2e211]
                  - paragraph [ref=f2e213]: Лофт «Квартал»
                - 'generic "Участников: 1" [ref=f2e220]':
                  - generic "Саша · Организатор" [ref=f2e221]:
                    - generic [aria-hidden] [ref=f2e222]: С
            - article [ref=f2e223]:
              - link [ref=f2e224] [cursor=pointer]:
                - /url: /meetings/6ab5c820-f41e-4f79-8867-1e9bb0d9e6c2
                - time [ref=f2e225]: Сб, 24 октября · 19:00
                - generic [ref=f2e226]:
                  - heading "Без движения Вы организатор" [level=2] [ref=f2e228]:
                    - text: Без
                    - generic [ref=f2e229]:
                      - generic [ref=f2e230]: движения
                      - img "Вы организатор" [ref=f2e231]
                  - paragraph [ref=f2e233]: Место пока не выбрано
                - 'generic "Участников: 1" [ref=f2e240]':
                  - generic "Саша · Организатор" [ref=f2e241]:
                    - generic [aria-hidden] [ref=f2e242]: С
            - article [ref=f2e243]:
              - link [ref=f2e244] [cursor=pointer]:
                - /url: /meetings/6baf4a73-46d8-46e6-b318-31fa0bffde43
                - time [ref=f2e245]: Сб, 24 октября · 19:00
                - generic [ref=f2e246]:
                  - heading "Без сети Вы организатор" [level=2] [ref=f2e248]:
                    - text: Без
                    - generic [ref=f2e249]:
                      - generic [ref=f2e250]: сети
                      - img "Вы организатор" [ref=f2e251]
                  - paragraph [ref=f2e253]: Место пока не выбрано
                - 'generic "Участников: 1" [ref=f2e260]':
                  - generic "Саша · Организатор" [ref=f2e261]:
                    - generic [aria-hidden] [ref=f2e262]: С
            - article [ref=f2e263]:
              - link [ref=f2e264] [cursor=pointer]:
                - /url: /meetings/7726e028-583c-4243-87ab-730e8d6567d7
                - time [ref=f2e265]: Сб, 24 октября · 19:00
                - generic [ref=f2e266]:
                  - heading "Раскладка 390 Вы организатор" [level=2] [ref=f2e268]:
                    - text: Раскладка
                    - generic [ref=f2e269]:
                      - generic [ref=f2e270]: "390"
                      - img "Вы организатор" [ref=f2e271]
                  - paragraph [ref=f2e273]: Место пока не выбрано
                - 'generic "Участников: 1" [ref=f2e280]':
                  - generic "Саша · Организатор" [ref=f2e281]:
                    - generic [aria-hidden] [ref=f2e282]: С
            - article [ref=f2e283]:
              - link [ref=f2e284] [cursor=pointer]:
                - /url: /meetings/81674e6e-a45f-4d04-8462-85665d160fdf
                - time [ref=f2e285]: Сб, 24 октября · 19:00
                - generic [ref=f2e286]:
                  - heading "Проверка отправки Вы организатор" [level=2] [ref=f2e288]:
                    - text: Проверка
                    - generic [ref=f2e289]:
                      - generic [ref=f2e290]: отправки
                      - img "Вы организатор" [ref=f2e291]
                  - paragraph [ref=f2e293]: Лофт «Квартал»
                - 'generic "Участников: 1" [ref=f2e300]':
                  - generic "Саша · Организатор" [ref=f2e301]:
                    - generic [aria-hidden] [ref=f2e302]: С
            - article [ref=f2e303]:
              - link [ref=f2e304] [cursor=pointer]:
                - /url: /meetings/8db18de5-8d72-4699-b383-9a618a5883a1
                - time [ref=f2e305]: Сб, 24 октября · 19:00
                - generic [ref=f2e306]:
                  - heading "Единственное действие 1440 Вы организатор" [level=2] [ref=f2e308]:
                    - text: Единственное действие
                    - generic [ref=f2e309]:
                      - generic [ref=f2e310]: "1440"
                      - img "Вы организатор" [ref=f2e311]
                  - paragraph [ref=f2e313]: Место пока не выбрано
                - 'generic "Участников: 1" [ref=f2e320]':
                  - generic "Саша · Организатор" [ref=f2e321]:
                    - generic [aria-hidden] [ref=f2e322]: С
            - article [ref=f2e323]:
              - link [ref=f2e324] [cursor=pointer]:
                - /url: /meetings/907d7965-7e08-4f7c-a7a8-2d124fcf5a22
                - time [ref=f2e325]: Сб, 24 октября · 19:00
                - generic [ref=f2e326]:
                  - heading "Раскладка 320 Вы организатор" [level=2] [ref=f2e328]:
                    - text: Раскладка
                    - generic [ref=f2e329]:
                      - generic [ref=f2e330]: "320"
                      - img "Вы организатор" [ref=f2e331]
                  - paragraph [ref=f2e333]: Место пока не выбрано
                - 'generic "Участников: 1" [ref=f2e340]':
                  - generic "Саша · Организатор" [ref=f2e341]:
                    - generic [aria-hidden] [ref=f2e342]: С
            - article [ref=f2e343]:
              - link [ref=f2e344] [cursor=pointer]:
                - /url: /meetings/c4141653-f029-4668-b9b0-008acd763796
                - time [ref=f2e345]: Сб, 24 октября · 19:00
                - generic [ref=f2e346]:
                  - heading "Суббота без спешки Вы организатор" [level=2] [ref=f2e348]:
                    - text: Суббота без
                    - generic [ref=f2e349]:
                      - generic [ref=f2e350]: спешки
                      - img "Вы организатор" [ref=f2e351]
                  - paragraph [ref=f2e353]: Лофт «Квартал»
                - 'generic "Участников: 2" [ref=f2e360]':
                  - generic "Саша · Организатор" [ref=f2e361]:
                    - generic [aria-hidden] [ref=f2e362]: С
                  - generic "Лена" [ref=f2e363]:
                    - generic [aria-hidden] [ref=f2e364]: Л
            - article [ref=f2e365]:
              - link [ref=f2e366] [cursor=pointer]:
                - /url: /meetings/cac2748c-2ab3-406d-b6fd-4b580eff10c4
                - time [ref=f2e367]: Сб, 24 октября · 19:00
                - generic [ref=f2e368]:
                  - heading "Сессия встречи Вы организатор" [level=2] [ref=f2e370]:
                    - text: Сессия
                    - generic [ref=f2e371]:
                      - generic [ref=f2e372]: встречи
                      - img "Вы организатор" [ref=f2e373]
                  - paragraph [ref=f2e375]: Место пока не выбрано
                - 'generic "Участников: 2" [ref=f2e382]':
                  - generic "Саша · Организатор" [ref=f2e383]:
                    - generic [aria-hidden] [ref=f2e384]: С
                  - generic "Лена" [ref=f2e385]:
                    - generic [aria-hidden] [ref=f2e386]: Л
            - article [ref=f2e387]:
              - link [ref=f2e388] [cursor=pointer]:
                - /url: /meetings/d60b2083-fee2-43bb-bcd2-5fe7474473f0
                - time [ref=f2e389]: Сб, 24 октября · 19:00
                - generic [ref=f2e390]:
                  - heading "Правка другого окна Вы организатор" [level=2] [ref=f2e392]:
                    - text: Правка другого
                    - generic [ref=f2e393]:
                      - generic [ref=f2e394]: окна
                      - img "Вы организатор" [ref=f2e395]
                  - paragraph [ref=f2e397]: Лофт «Квартал»
                - 'generic "Участников: 1" [ref=f2e404]':
                  - generic "Саша · Организатор" [ref=f2e405]:
                    - generic [aria-hidden] [ref=f2e406]: С
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test';
  2  | import { apiCreate, apiMeeting, login, writeHeaders } from '@tests/helpers';
  3  | 
  4  | test('short invitation provides fresh metadata and PNG without JavaScript', async ({
  5  |   page,
  6  |   browser,
  7  | }) => {
  8  |   await login(page, 'Саша');
  9  |   const created = await apiCreate(page, 'Настолки "дома"');
  10 |   const invitation = created.invitation_url;
  11 |   expect(new URL(invitation).pathname).toMatch(/^\/i\/[A-Za-z0-9_-]{22}$/);
  12 |   const description = 'Пицца & игры <script>window.injected=true</script> "до ночи"';
  13 |   const changed = await page.request.patch(`/api/v1/meetings/${created.meeting.id}`, {
  14 |     headers: await writeHeaders(page),
  15 |     data: { description, expected_revision: created.meeting.revision },
  16 |   });
  17 | 
  18 |   expect(changed.status()).toBe(200);
  19 |   const context = await browser.newContext({
  20 |     javaScriptEnabled: false,
  21 |     ignoreHTTPSErrors: true,
  22 |   });
  23 | 
  24 |   const publicPage = await context.newPage();
  25 |   const response = await publicPage.goto(invitation);
  26 |   expect(response?.status()).toBe(200);
  27 |   await expect(publicPage.locator('meta[property="og:title"]')).toHaveAttribute(
  28 |     'content',
  29 |     'Настолки "дома"',
  30 |   );
  31 |   await expect(publicPage.locator('meta[property="og:description"]')).toHaveAttribute(
  32 |     'content',
  33 |     description,
  34 |   );
  35 |   await expect(publicPage.locator('meta[property="og:url"]')).toHaveAttribute(
  36 |     'content',
  37 |     invitation,
  38 |   );
  39 |   await expect(publicPage.locator('link[rel="canonical"]')).toHaveAttribute(
  40 |     'href',
  41 |     invitation,
  42 |   );
  43 |   await expect(publicPage.locator('meta[name="description"]')).toHaveCount(1);
  44 |   await expect(publicPage.locator('title')).toHaveCount(1);
  45 |   await expect(publicPage.locator('script:not([src])')).toHaveCount(0);
  46 |   const raw = await response?.text();
  47 |   expect(raw).toContain('&lt;script&gt;');
  48 |   expect(raw).not.toContain('<script>window.injected');
  49 |   expect(raw).not.toContain('organizer_id');
  50 |   expect(raw).not.toContain('participant_count');
  51 |   const image = await publicPage
  52 |     .locator('meta[property="og:image"]')
  53 |     .getAttribute('content');
  54 | 
> 55 |   expect(image).toBe('https://127.0.0.1:8444/share-card.png');
     |                 ^ Error: expect(received).toBe(expected) // Object.is equality
  56 |   const picture = await context.request.get(image ?? '');
  57 |   expect(picture.status()).toBe(200);
  58 |   expect(picture.headers()['content-type']).toContain('image/png');
  59 |   const png = await picture.body();
  60 |   expect(png.subarray(1, 4).toString()).toBe('PNG');
  61 |   expect(png.readUInt32BE(16)).toBe(1200);
  62 |   expect(png.readUInt32BE(20)).toBe(630);
  63 |   const head = await context.request.head(invitation);
  64 |   expect(head.status()).toBe(200);
  65 |   expect((await head.body()).length).toBe(0);
  66 |   await publicPage.goto(invitation.replace('/i/', '/invitations/'));
  67 |   await expect(publicPage).toHaveURL(invitation);
  68 |   const meeting = await apiMeeting(page, created.meeting.id);
  69 |   const update = await page.request.patch(`/api/v1/meetings/${meeting.id}`, {
  70 |     headers: await writeHeaders(page),
  71 |     data: { description: 'Обновлённое описание', expected_revision: meeting.revision },
  72 |   });
  73 | 
  74 |   expect(update.status()).toBe(200);
  75 |   await publicPage.reload();
  76 |   await expect(publicPage.locator('meta[property="og:description"]')).toHaveAttribute(
  77 |     'content',
  78 |     'Обновлённое описание',
  79 |   );
  80 |   const missing = await publicPage.goto('/i/AAAAAAAAAAAAAAAAAAAAAA');
  81 |   expect(missing?.status()).toBe(404);
  82 |   await expect(publicPage.locator('meta[property="og:title"]')).toHaveCount(0);
  83 |   await context.close();
  84 | });
  85 | 
```