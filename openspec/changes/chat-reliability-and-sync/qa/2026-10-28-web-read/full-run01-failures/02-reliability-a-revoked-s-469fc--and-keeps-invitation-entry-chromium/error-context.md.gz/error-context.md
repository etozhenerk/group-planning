# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 02-reliability.spec.ts >> a revoked session closes private content and keeps invitation entry
- Location: tests/02-reliability.spec.ts:165:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 204
Received: 403
```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - link "К содержимому" [ref=f2e4] [cursor=pointer]:
    - /url: "#main"
  - generic [ref=f2e5]: Демостенд · данные хранятся до перезапуска
  - generic [ref=f2e6]:
    - navigation "Основная навигация" [ref=f2e8]:
      - link "Somewhere — на главную" [ref=f2e10] [cursor=pointer]:
        - /url: /
        - generic [ref=f2e11]: somewhere
      - generic [ref=f2e12]:
        - link "Встречи" [ref=f2e13] [cursor=pointer]:
          - /url: /meetings
          - generic [ref=f2e16]: Мои встречи
        - link "Приглашения" [ref=f2e17] [cursor=pointer]:
          - /url: /invitations
        - link "Сообщить о проблеме" [ref=f2e22] [cursor=pointer]:
          - /url: /support
        - link "Профиль" [ref=f2e26] [cursor=pointer]:
          - /url: /profile
          - generic [aria-hidden] [ref=f2e28]: С
          - generic [ref=f2e29]:
            - strong [ref=f2e30]: Саша
            - generic [ref=f2e31]: Мой профиль
    - main [active] [ref=f2e33]:
      - generic [ref=f2e35]:
        - heading "Мои встречи" [level=1] [ref=f2e36]
        - link "Создать встречу" [ref=f2e37] [cursor=pointer]:
          - /url: /meetings/new
          - text: Создать
      - generic [ref=f2e39]:
        - navigation "Период встреч" [ref=f2e40]:
          - button "Предстоящие 3" [pressed] [ref=f2e41] [cursor=pointer]:
            - text: Предстоящие
            - generic [ref=f2e42]: "3"
          - button "Прошедшие 1" [ref=f2e43] [cursor=pointer]:
            - text: Прошедшие
            - generic [ref=f2e44]: "1"
        - navigation "Вид встреч" [ref=f2e45]:
          - button "Список" [pressed] [ref=f2e46] [cursor=pointer]
          - button "Календарь" [ref=f2e48] [cursor=pointer]
      - generic [ref=f2e53]:
        - heading "октябрь 2099" [level=2] [ref=f2e54]
        - generic [ref=f2e55]:
          - article [ref=f2e56]:
            - link [ref=f2e57] [cursor=pointer]:
              - /url: /meetings/81674e6e-a45f-4d04-8462-85665d160fdf
              - time [ref=f2e58]: Сб, 24 октября · 19:00
              - generic [ref=f2e59]:
                - heading "Проверка отправки Вы организатор" [level=2] [ref=f2e61]:
                  - text: Проверка
                  - generic [ref=f2e62]:
                    - generic [ref=f2e63]: отправки
                    - img "Вы организатор" [ref=f2e64]
                - paragraph [ref=f2e66]: Лофт «Квартал»
              - 'generic "Участников: 1" [ref=f2e73]':
                - generic "Саша · Организатор" [ref=f2e74]:
                  - generic [aria-hidden] [ref=f2e75]: С
          - article [ref=f2e76]:
            - link [ref=f2e77] [cursor=pointer]:
              - /url: /meetings/c4141653-f029-4668-b9b0-008acd763796
              - time [ref=f2e78]: Сб, 24 октября · 19:00
              - generic [ref=f2e79]:
                - heading "Суббота без спешки Вы организатор" [level=2] [ref=f2e81]:
                  - text: Суббота без
                  - generic [ref=f2e82]:
                    - generic [ref=f2e83]: спешки
                    - img "Вы организатор" [ref=f2e84]
                - paragraph [ref=f2e86]: Лофт «Квартал»
              - 'generic "Участников: 2" [ref=f2e93]':
                - generic "Саша · Организатор" [ref=f2e94]:
                  - generic [aria-hidden] [ref=f2e95]: С
                - generic "Лена" [ref=f2e96]:
                  - generic [aria-hidden] [ref=f2e97]: Л
          - article [ref=f2e98]:
            - link [ref=f2e99] [cursor=pointer]:
              - /url: /meetings/d60b2083-fee2-43bb-bcd2-5fe7474473f0
              - time [ref=f2e100]: Сб, 24 октября · 19:00
              - generic [ref=f2e101]:
                - heading "Правка другого окна Вы организатор" [level=2] [ref=f2e103]:
                  - text: Правка другого
                  - generic [ref=f2e104]:
                    - generic [ref=f2e105]: окна
                    - img "Вы организатор" [ref=f2e106]
                - paragraph [ref=f2e108]: Лофт «Квартал»
              - 'generic "Участников: 1" [ref=f2e115]':
                - generic "Саша · Организатор" [ref=f2e116]:
                  - generic [aria-hidden] [ref=f2e117]: С
```

# Test source

```ts
  84  |   const keys: string[] = [];
  85  |   const second: { release?: () => void } = {};
  86  |   await page.route(`**/api/v1/meetings/${id}/feed?*`, async (route) => {
  87  |     if (posts === 1) {
  88  |       await route.abort('connectionreset');
  89  |     } else {
  90  |       await route.continue();
  91  |     }
  92  |   });
  93  |   await page.route(`**/api/v1/meetings/${id}/messages`, async (route) => {
  94  |     posts++;
  95  |     keys.push(route.request().headers()['idempotency-key'] ?? '');
  96  | 
  97  |     if (posts === 1) {
  98  |       await route.fetch();
  99  |       await route.abort('connectionreset');
  100 |     } else {
  101 |       await new Promise<void>((resolve) => {
  102 |         second.release = resolve;
  103 |       });
  104 |       await route.continue();
  105 |     }
  106 |   });
  107 |   await page.getByLabel('Сообщение', { exact: true }).fill('Повтор без дубля');
  108 |   await page.getByRole('button', { name: 'Отправить сообщение' }).click();
  109 |   const row = page.getByTestId('feed-message').filter({ hasText: 'Повтор без дубля' });
  110 |   await expect(row).toHaveAttribute('data-delivery', 'uncertain');
  111 |   await row.evaluate((element) => element.setAttribute('data-before-retry', 'yes'));
  112 |   await expectMessageSide(page, 'Повтор без дубля', 'right');
  113 |   await expect.poll(() => keys.length).toBe(2);
  114 |   expect(keys[0]).not.toBe('');
  115 |   expect(keys[0]).toBe(keys[1]);
  116 |   second.release?.();
  117 |   await expect(row).toHaveAttribute('data-delivery', 'accepted');
  118 |   await expect(row).toHaveAttribute('data-before-retry', 'yes');
  119 |   await expect(page.getByText('Повтор без дубля', { exact: true })).toHaveCount(1);
  120 |   await expectMessageSide(page, 'Повтор без дубля', 'right');
  121 |   await page.reload();
  122 |   await expect(page.getByText('Повтор без дубля', { exact: true })).toHaveCount(1);
  123 | });
  124 | 
  125 | test('history and a stale settings form preserve authoritative state', async ({
  126 |   page,
  127 | }) => {
  128 |   await login(page, 'Саша');
  129 |   const id = await create(page, 'История и настройки');
  130 |   const headers = await writeHeaders(page);
  131 | 
  132 |   for (let n = 0; n < 58; n++) {
  133 |     const key = randomUUID();
  134 |     const response = await page.request.post(`/api/v1/meetings/${id}/messages`, {
  135 |       headers: { ...headers, 'Idempotency-Key': key },
  136 |       data: { text: `Запись истории ${n}`, client_request_id: key },
  137 |     });
  138 | 
  139 |     expect(response.status()).toBe(201);
  140 |   }
  141 | 
  142 |   await page.goto(`/meetings/${id}`);
  143 |   await expect(page.getByText('Запись истории 0', { exact: true })).toHaveCount(0);
  144 |   await page.getByRole('button', { name: 'Предыдущие записи' }).click();
  145 |   await expect(page.getByText('Запись истории 0', { exact: true })).toBeVisible();
  146 |   await page.getByRole('button', { name: 'Информация о встрече' }).click();
  147 |   await page.getByRole('button', { name: 'Изменить настройки', exact: true }).click();
  148 |   const dialog = page.getByRole('dialog', { name: 'Настройки встречи' });
  149 |   await dialog.getByLabel('Название', { exact: true }).fill('Старая правка');
  150 |   const meeting = await apiMeeting(page, id);
  151 |   const changed = await page.request.patch(`/api/v1/meetings/${id}`, {
  152 |     headers,
  153 |     data: { title: 'Правка другого окна', expected_revision: meeting.revision },
  154 |   });
  155 | 
  156 |   expect(changed.status()).toBe(200);
  157 |   await dialog.getByRole('button', { name: 'Сохранить изменения' }).click();
  158 |   await expect(dialog.getByRole('alert')).toContainText('Данные изменились');
  159 |   await expect(dialog.getByLabel('Название', { exact: true })).toHaveValue(
  160 |     'Старая правка',
  161 |   );
  162 |   expect((await apiMeeting(page, id)).title).toBe('Правка другого окна');
  163 | });
  164 | 
  165 | test('a revoked session closes private content and keeps invitation entry', async ({
  166 |   page,
  167 |   browser,
  168 | }) => {
  169 |   await login(page, 'Саша');
  170 |   const created = await apiCreate(page, 'Сессия встречи');
  171 |   const url = created.invitation_url;
  172 |   const context = await browser.newContext({ ignoreHTTPSErrors: true });
  173 |   const friend = await context.newPage();
  174 |   await friend.goto(url);
  175 |   await friend.getByRole('button', { name: 'Войти и ответить' }).click();
  176 |   await friend.getByRole('link', { name: 'Войти как Лена' }).click();
  177 |   await friend.getByRole('button', { name: 'Приду', exact: true }).click();
  178 |   await friend.getByRole('link', { name: 'Открыть встречу', exact: true }).click();
  179 |   await expect(friend.getByLabel('Сообщение', { exact: true })).toBeVisible();
  180 |   const logout = await friend.request.post('/api/v1/auth/logout', {
  181 |     headers: { Origin: 'https://127.0.0.1:8444', 'X-CSRF-Token': await csrf(friend) },
  182 |   });
  183 | 
> 184 |   expect(logout.status()).toBe(204);
      |                           ^ Error: expect(received).toBe(expected) // Object.is equality
  185 |   await expect(friend.getByRole('button', { name: 'Войти через Яндекс ID' })).toBeVisible(
  186 |     { timeout: 10_000 },
  187 |   );
  188 |   await expect(friend.getByLabel('Сообщение', { exact: true })).toHaveCount(0);
  189 |   await friend.getByRole('button', { name: 'Войти через Яндекс ID' }).click();
  190 |   await friend.getByRole('link', { name: 'Войти как Лена' }).click();
  191 |   await expect(friend).toHaveURL(url);
  192 |   await context.close();
  193 | });
  194 | 
  195 | test('cancelled invitation sign-in stays on the invitation without an answer', async ({
  196 |   page,
  197 | }) => {
  198 |   await login(page, 'Саша');
  199 |   await create(page, 'Отмена входа');
  200 |   const url = await inviteLink(page);
  201 |   await page.getByRole('link', { name: 'Профиль', exact: true }).click();
  202 |   await page.getByRole('button', { name: 'Выйти из аккаунта' }).click();
  203 |   await page.goto(url);
  204 |   await page.getByRole('button', { name: 'Войти и ответить' }).click();
  205 |   await page.getByRole('link', { name: 'Отменить вход' }).click();
  206 |   await expect(page).toHaveURL(/\/i\/.*auth_error=cancelled/);
  207 |   await expect(page.getByRole('status')).toContainText('Вход отменён');
  208 |   await expect(page.getByLabel('Сообщение', { exact: true })).toHaveCount(0);
  209 | });
  210 | 
```