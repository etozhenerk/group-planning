# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 19-shared-session.spec.ts >> two sessions of one profile share access and reject a stale join and message retry
- Location: tests/19-shared-session.spec.ts:6:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 401
Received: 200
```

# Page snapshot

```yaml
- generic [ref=f3e3]:
  - link "К содержимому" [ref=f3e4] [cursor=pointer]:
    - /url: "#main"
  - generic [ref=f3e5]: Демостенд · данные хранятся до перезапуска
  - generic [ref=f3e6]:
    - navigation "Основная навигация" [ref=f3e8]:
      - link "Somewhere — на главную" [ref=f3e10] [cursor=pointer]:
        - /url: /
        - generic [ref=f3e11]: somewhere
      - generic [ref=f3e12]:
        - link "Встречи" [ref=f3e13] [cursor=pointer]:
          - /url: /meetings
          - generic [ref=f3e16]: Мои встречи
        - link "Приглашения" [ref=f3e17] [cursor=pointer]:
          - /url: /invitations
        - link "Сообщить о проблеме" [ref=f3e22] [cursor=pointer]:
          - /url: /support
        - link "Профиль" [ref=f3e26] [cursor=pointer]:
          - /url: /profile
          - generic [aria-hidden] [ref=f3e28]: С
          - generic [ref=f3e29]:
            - strong [ref=f3e30]: Саша
            - generic [ref=f3e31]: Мой профиль
    - generic [ref=f3e32]:
      - main [ref=f3e33]:
        - generic [ref=f3e34]:
          - link "К моим встречам" [ref=f3e35] [cursor=pointer]:
            - /url: /meetings
          - generic [ref=f3e38]:
            - heading "Два устройства одного профиля" [level=1] [ref=f3e39]
            - paragraph [ref=f3e40]: 1 участник · 24 октября · 19:00
          - button "Пригласить друзей" [ref=f3e42] [cursor=pointer]
          - button "Информация о встрече" [ref=f3e45] [cursor=pointer]
        - list "Разговор встречи" [ref=f3e51]:
          - listitem [ref=f3e53]:
            - time [ref=f3e54]: Сегодня · 01:13
            - paragraph [ref=f3e55]: Саша создал встречу
          - listitem [ref=f3e57]:
            - time [ref=f3e58]: Сегодня · 01:13
            - paragraph [ref=f3e59]: Лена ответил «Приду»
          - listitem [ref=f3e61]:
            - generic [aria-hidden] [ref=f3e62]: Л
            - generic [ref=f3e63]:
              - generic [ref=f3e64]:
                - strong [ref=f3e65]: Лена
                - time [ref=f3e66]: 01:13
              - 'group "Реакции на сообщение: Единственное сообщение" [ref=f3e67]':
                - paragraph [ref=f3e68]: Единственное сообщение
          - listitem [ref=f3e70]:
            - time [ref=f3e71]: Сегодня · 01:13
            - paragraph [ref=f3e72]: Лена ответил «Возможно»
        - generic [ref=f3e75]:
          - button "Добавить к встрече" [ref=f3e77] [cursor=pointer]
          - generic [ref=f3e80]:
            - generic [ref=f3e81]:
              - generic [ref=f3e82]: Сообщение
              - textbox "Сообщение" [ref=f3e83]:
                - /placeholder: Сообщение…
            - button "Выбрать эмодзи" [ref=f3e84] [cursor=pointer]
          - button "Отправить сообщение" [disabled] [ref=f3e90]
      - complementary [ref=f3e93]:
        - generic [ref=f3e94]:
          - generic [ref=f3e95]:
            - generic [ref=f3e96]:
              - term [ref=f3e97]: Когда
              - definition [ref=f3e98]:
                - generic [ref=f3e99]: 24 октября в 19:00
                - generic [ref=f3e100]: Москва
            - generic [ref=f3e101]:
              - term [ref=f3e102]: Где
              - definition [ref=f3e103]: Место пока не выбрано
          - generic [ref=f3e104]:
            - heading "Кто придёт · 1" [level=3] [ref=f3e105]
            - 'button "Все участники встречи. Придут: 1" [ref=f3e106] [cursor=pointer]':
              - generic "Саша" [ref=f3e107]:
                - generic [aria-hidden] [ref=f3e108]: С
                - text: Саша
```

# Test source

```ts
  6   | test('two sessions of one profile share access and reject a stale join and message retry', async ({
  7   |   page,
  8   |   browser,
  9   | }) => {
  10  |   await login(page, 'Саша');
  11  |   const created = await apiCreate(page, 'Два устройства одного профиля');
  12  |   const base = `/api/v1/meetings/${created.meeting.id}`;
  13  |   const [firstContext, secondContext] = await Promise.all([
  14  |     browser.newContext({ ignoreHTTPSErrors: true }),
  15  |     browser.newContext({ ignoreHTTPSErrors: true }),
  16  |   ]);
  17  | 
  18  |   try {
  19  |     const first = await firstContext.newPage();
  20  |     const second = await secondContext.newPage();
  21  |     await login(first, 'Лена');
  22  |     await login(second, 'Лена');
  23  |     const firstSession = sessionSchema.parse(
  24  |       await (await first.request.get('/api/v1/me')).json(),
  25  |     );
  26  | 
  27  |     const secondSession = sessionSchema.parse(
  28  |       await (await second.request.get('/api/v1/me')).json(),
  29  |     );
  30  | 
  31  |     expect(firstSession.user.id).toBe(secondSession.user.id);
  32  |     expect(firstSession.csrf_token).not.toBe(secondSession.csrf_token);
  33  |     const joinKey = crypto.randomUUID();
  34  |     const invitePath = new URL(created.invitation_url).pathname.replace(
  35  |       '/i/',
  36  |       '/api/v1/invitations/',
  37  |     );
  38  | 
  39  |     const join = { answer: 'going', expected_revision: '0' };
  40  |     const joined = await first.request.put(`${invitePath}/rsvp`, {
  41  |       headers: await writeHeaders(first, joinKey),
  42  |       data: join,
  43  |     });
  44  | 
  45  |     expect(joined.status()).toBe(200);
  46  |     await first.goto(`/meetings/${created.meeting.id}`);
  47  |     await second.goto(`/meetings/${created.meeting.id}`);
  48  |     await expect(first.getByLabel('Сообщение', { exact: true })).toBeVisible();
  49  |     await expect(second.getByLabel('Сообщение', { exact: true })).toBeVisible();
  50  |     let pending: Route | undefined;
  51  |     let saved = false;
  52  |     await first.route(`**${base}/messages`, async (route) => {
  53  |       pending = route;
  54  |       const response = await route.fetch();
  55  |       expect(response.status()).toBe(201);
  56  |       saved = true;
  57  |     });
  58  |     await first.getByLabel('Сообщение', { exact: true }).fill('Единственное сообщение');
  59  |     await first.getByRole('button', { name: 'Отправить сообщение' }).click();
  60  |     await expect.poll(() => saved).toBe(true);
  61  |     const withdrawn = await second.request.put(`${base}/rsvp`, {
  62  |       headers: await writeHeaders(second),
  63  |       data: { answer: 'maybe', expected_revision: '1' },
  64  |     });
  65  | 
  66  |     expect(withdrawn.status()).toBe(200);
  67  |     await expect(first.getByRole('heading', { name: 'Переписка закрыта' })).toBeVisible({
  68  |       timeout: 10000,
  69  |     });
  70  |     await expect(second.getByRole('heading', { name: 'Переписка закрыта' })).toBeVisible({
  71  |       timeout: 10000,
  72  |     });
  73  |     const repeated = await first.request.put(`${invitePath}/rsvp`, {
  74  |       headers: await writeHeaders(first, joinKey),
  75  |       data: join,
  76  |     });
  77  | 
  78  |     expect(repeated.status()).toBe(200);
  79  |     expect(responseSchema.parse(await repeated.json()).can_access_feed).toBe(false);
  80  | 
  81  |     if (!pending) {
  82  |       throw new Error('Expected one pending message request');
  83  |     }
  84  | 
  85  |     const retry = await first.request.post(`${base}/messages`, {
  86  |       headers: {
  87  |         ...(await writeHeaders(first, pending.request().headers()['idempotency-key'])),
  88  |         'Content-Type': 'application/json',
  89  |       },
  90  |       data: pending.request().postData() ?? '',
  91  |     });
  92  | 
  93  |     expect(retry.status()).toBe(403);
  94  |     await pending.abort('failed');
  95  |     await expect(first.getByLabel('Сообщение', { exact: true })).toHaveCount(0);
  96  |     await expect(first.getByText('Единственное сообщение', { exact: true })).toHaveCount(
  97  |       0,
  98  |     );
  99  |     await page.goto(`/meetings/${created.meeting.id}`);
  100 |     await expect(page.getByText('Единственное сообщение', { exact: true })).toHaveCount(
  101 |       1,
  102 |     );
  103 |     await first.request.post('/api/v1/auth/logout', {
  104 |       headers: { Origin: 'https://127.0.0.1:8444', 'X-CSRF-Token': await csrf(first) },
  105 |     });
> 106 |     expect((await first.request.get('/api/v1/me')).status()).toBe(401);
      |                                                              ^ Error: expect(received).toBe(expected) // Object.is equality
  107 |     expect((await second.request.get('/api/v1/me')).status()).toBe(200);
  108 |   } finally {
  109 |     await Promise.all([firstContext.close(), secondContext.close()]);
  110 |   }
  111 | });
  112 | 
```