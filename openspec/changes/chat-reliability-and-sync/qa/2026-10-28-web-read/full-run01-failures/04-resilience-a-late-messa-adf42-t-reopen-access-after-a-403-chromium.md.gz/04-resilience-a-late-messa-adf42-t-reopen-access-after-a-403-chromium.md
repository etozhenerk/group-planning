# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 04-resilience.spec.ts >> a late message response cannot reopen access after a 403
- Location: tests/04-resilience.spec.ts:34:1

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 200
Received: 403
```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - link "К содержимому" [ref=f2e4] [cursor=pointer]:
    - /url: "#main"
  - generic [ref=f2e5]: Демостенд · данные хранятся до перезапуска
  - generic [ref=f2e6]:
    - navigation "Основная навигация" [ref=f2e8]:
      - link "Somewhere — на главную" [ref=f2e10] [cursor=pointer]:
        - /url: /
        - generic [ref=f2e11]: somewhere
      - generic [ref=f2e12]:
        - link "Встречи" [ref=f2e13] [cursor=pointer]:
          - /url: /meetings
          - generic [ref=f2e16]: Мои встречи
        - link "Приглашения" [ref=f2e17] [cursor=pointer]:
          - /url: /invitations
        - link "Сообщить о проблеме" [ref=f2e22] [cursor=pointer]:
          - /url: /support
        - link "Профиль" [ref=f2e26] [cursor=pointer]:
          - /url: /profile
          - generic [aria-hidden] [ref=f2e28]: С
          - generic [ref=f2e29]:
            - strong [ref=f2e30]: Саша
            - generic [ref=f2e31]: Мой профиль
    - main [active] [ref=f2e33]:
      - generic [ref=f2e35]:
        - heading "Мои встречи" [level=1] [ref=f2e36]
        - link "Создать встречу" [ref=f2e37] [cursor=pointer]:
          - /url: /meetings/new
          - text: Создать
      - generic [ref=f2e39]:
        - navigation "Период встреч" [ref=f2e40]:
          - button "Предстоящие 11" [pressed] [ref=f2e41] [cursor=pointer]:
            - text: Предстоящие
            - generic [ref=f2e42]: "11"
          - button "Прошедшие 1" [ref=f2e43] [cursor=pointer]:
            - text: Прошедшие
            - generic [ref=f2e44]: "1"
        - navigation "Вид встреч" [ref=f2e45]:
          - button "Список" [pressed] [ref=f2e46] [cursor=pointer]
          - button "Календарь" [ref=f2e48] [cursor=pointer]
      - generic [ref=f2e53]:
        - heading "октябрь 2099" [level=2] [ref=f2e54]
        - generic [ref=f2e55]:
          - article [ref=f2e56]:
            - link [ref=f2e57] [cursor=pointer]:
              - /url: /meetings/03924827-5b2a-42ca-98f6-6ca9abacac0f
              - time [ref=f2e58]: Сб, 24 октября · 19:00
              - generic [ref=f2e59]:
                - heading "Раскладка 1440 Вы организатор" [level=2] [ref=f2e61]:
                  - text: Раскладка
                  - generic [ref=f2e62]:
                    - generic [ref=f2e63]: "1440"
                    - img "Вы организатор" [ref=f2e64]
                - paragraph [ref=f2e66]: Место пока не выбрано
              - 'generic "Участников: 1" [ref=f2e73]':
                - generic "Саша · Организатор" [ref=f2e74]:
                  - generic [aria-hidden] [ref=f2e75]: С
          - article [ref=f2e76]:
            - link [ref=f2e77] [cursor=pointer]:
              - /url: /meetings/6811b074-7921-498b-9cf0-f6c5000f3306
              - time [ref=f2e78]: Сб, 24 октября · 19:00
              - generic [ref=f2e79]:
                - heading "Раскладка 768 Вы организатор" [level=2] [ref=f2e81]:
                  - text: Раскладка
                  - generic [ref=f2e82]:
                    - generic [ref=f2e83]: "768"
                    - img "Вы организатор" [ref=f2e84]
                - paragraph [ref=f2e86]: Место пока не выбрано
              - 'generic "Участников: 1" [ref=f2e93]':
                - generic "Саша · Организатор" [ref=f2e94]:
                  - generic [aria-hidden] [ref=f2e95]: С
          - article [ref=f2e96]:
            - link [ref=f2e97] [cursor=pointer]:
              - /url: /meetings/697134e2-9df3-4eed-a0e8-ef8c505dedad
              - time [ref=f2e98]: Сб, 24 октября · 19:00
              - generic [ref=f2e99]:
                - heading "Отмена входа Вы организатор" [level=2] [ref=f2e101]:
                  - text: Отмена
                  - generic [ref=f2e102]:
                    - generic [ref=f2e103]: входа
                    - img "Вы организатор" [ref=f2e104]
                - paragraph [ref=f2e106]: Лофт «Квартал»
              - 'generic "Участников: 1" [ref=f2e113]':
                - generic "Саша · Организатор" [ref=f2e114]:
                  - generic [aria-hidden] [ref=f2e115]: С
          - article [ref=f2e116]:
            - link [ref=f2e117] [cursor=pointer]:
              - /url: /meetings/6ab5c820-f41e-4f79-8867-1e9bb0d9e6c2
              - time [ref=f2e118]: Сб, 24 октября · 19:00
              - generic [ref=f2e119]:
                - heading "Без движения Вы организатор" [level=2] [ref=f2e121]:
                  - text: Без
                  - generic [ref=f2e122]:
                    - generic [ref=f2e123]: движения
                    - img "Вы организатор" [ref=f2e124]
                - paragraph [ref=f2e126]: Место пока не выбрано
              - 'generic "Участников: 1" [ref=f2e133]':
                - generic "Саша · Организатор" [ref=f2e134]:
                  - generic [aria-hidden] [ref=f2e135]: С
          - article [ref=f2e136]:
            - link [ref=f2e137] [cursor=pointer]:
              - /url: /meetings/6baf4a73-46d8-46e6-b318-31fa0bffde43
              - time [ref=f2e138]: Сб, 24 октября · 19:00
              - generic [ref=f2e139]:
                - heading "Без сети Вы организатор" [level=2] [ref=f2e141]:
                  - text: Без
                  - generic [ref=f2e142]:
                    - generic [ref=f2e143]: сети
                    - img "Вы организатор" [ref=f2e144]
                - paragraph [ref=f2e146]: Место пока не выбрано
              - 'generic "Участников: 1" [ref=f2e153]':
                - generic "Саша · Организатор" [ref=f2e154]:
                  - generic [aria-hidden] [ref=f2e155]: С
          - article [ref=f2e156]:
            - link [ref=f2e157] [cursor=pointer]:
              - /url: /meetings/7726e028-583c-4243-87ab-730e8d6567d7
              - time [ref=f2e158]: Сб, 24 октября · 19:00
              - generic [ref=f2e159]:
                - heading "Раскладка 390 Вы организатор" [level=2] [ref=f2e161]:
                  - text: Раскладка
                  - generic [ref=f2e162]:
                    - generic [ref=f2e163]: "390"
                    - img "Вы организатор" [ref=f2e164]
                - paragraph [ref=f2e166]: Место пока не выбрано
              - 'generic "Участников: 1" [ref=f2e173]':
                - generic "Саша · Организатор" [ref=f2e174]:
                  - generic [aria-hidden] [ref=f2e175]: С
          - article [ref=f2e176]:
            - link [ref=f2e177] [cursor=pointer]:
              - /url: /meetings/81674e6e-a45f-4d04-8462-85665d160fdf
              - time [ref=f2e178]: Сб, 24 октября · 19:00
              - generic [ref=f2e179]:
                - heading "Проверка отправки Вы организатор" [level=2] [ref=f2e181]:
                  - text: Проверка
                  - generic [ref=f2e182]:
                    - generic [ref=f2e183]: отправки
                    - img "Вы организатор" [ref=f2e184]
                - paragraph [ref=f2e186]: Лофт «Квартал»
              - 'generic "Участников: 1" [ref=f2e193]':
                - generic "Саша · Организатор" [ref=f2e194]:
                  - generic [aria-hidden] [ref=f2e195]: С
          - article [ref=f2e196]:
            - link [ref=f2e197] [cursor=pointer]:
              - /url: /meetings/907d7965-7e08-4f7c-a7a8-2d124fcf5a22
              - time [ref=f2e198]: Сб, 24 октября · 19:00
              - generic [ref=f2e199]:
                - heading "Раскладка 320 Вы организатор" [level=2] [ref=f2e201]:
                  - text: Раскладка
                  - generic [ref=f2e202]:
                    - generic [ref=f2e203]: "320"
                    - img "Вы организатор" [ref=f2e204]
                - paragraph [ref=f2e206]: Место пока не выбрано
              - 'generic "Участников: 1" [ref=f2e213]':
                - generic "Саша · Организатор" [ref=f2e214]:
                  - generic [aria-hidden] [ref=f2e215]: С
          - article [ref=f2e216]:
            - link [ref=f2e217] [cursor=pointer]:
              - /url: /meetings/c4141653-f029-4668-b9b0-008acd763796
              - time [ref=f2e218]: Сб, 24 октября · 19:00
              - generic [ref=f2e219]:
                - heading "Суббота без спешки Вы организатор" [level=2] [ref=f2e221]:
                  - text: Суббота без
                  - generic [ref=f2e222]:
                    - generic [ref=f2e223]: спешки
                    - img "Вы организатор" [ref=f2e224]
                - paragraph [ref=f2e226]: Лофт «Квартал»
              - 'generic "Участников: 2" [ref=f2e233]':
                - generic "Саша · Организатор" [ref=f2e234]:
                  - generic [aria-hidden] [ref=f2e235]: С
                - generic "Лена" [ref=f2e236]:
                  - generic [aria-hidden] [ref=f2e237]: Л
          - article [ref=f2e238]:
            - link [ref=f2e239] [cursor=pointer]:
              - /url: /meetings/cac2748c-2ab3-406d-b6fd-4b580eff10c4
              - time [ref=f2e240]: Сб, 24 октября · 19:00
              - generic [ref=f2e241]:
                - heading "Сессия встречи Вы организатор" [level=2] [ref=f2e243]:
                  - text: Сессия
                  - generic [ref=f2e244]:
                    - generic [ref=f2e245]: встречи
                    - img "Вы организатор" [ref=f2e246]
                - paragraph [ref=f2e248]: Место пока не выбрано
              - 'generic "Участников: 2" [ref=f2e255]':
                - generic "Саша · Организатор" [ref=f2e256]:
                  - generic [aria-hidden] [ref=f2e257]: С
                - generic "Лена" [ref=f2e258]:
                  - generic [aria-hidden] [ref=f2e259]: Л
          - article [ref=f2e260]:
            - link [ref=f2e261] [cursor=pointer]:
              - /url: /meetings/d60b2083-fee2-43bb-bcd2-5fe7474473f0
              - time [ref=f2e262]: Сб, 24 октября · 19:00
              - generic [ref=f2e263]:
                - heading "Правка другого окна Вы организатор" [level=2] [ref=f2e265]:
                  - text: Правка другого
                  - generic [ref=f2e266]:
                    - generic [ref=f2e267]: окна
                    - img "Вы организатор" [ref=f2e268]
                - paragraph [ref=f2e270]: Лофт «Квартал»
              - 'generic "Участников: 1" [ref=f2e277]':
                - generic "Саша · Организатор" [ref=f2e278]:
                  - generic [aria-hidden] [ref=f2e279]: С
```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test';
  2   | import {
  3   |   apiCreate,
  4   |   apiMeeting,
  5   |   csrf,
  6   |   expectDate,
  7   |   login,
  8   |   writeHeaders,
  9   | } from '@tests/helpers';
  10  | 
  11  | test('an offline message keeps its text and can be retried after reconnecting', async ({
  12  |   page,
  13  |   context,
  14  | }) => {
  15  |   await login(page, 'Саша');
  16  |   const created = await apiCreate(page, 'Без сети');
  17  |   await page.goto(`/meetings/${created.meeting.id}`);
  18  |   await expect(page.getByLabel('Сообщение', { exact: true })).toBeVisible();
  19  |   await context.setOffline(true);
  20  |   await page.getByLabel('Сообщение', { exact: true }).fill('Сообщение без сети');
  21  |   await page.getByRole('button', { name: 'Отправить сообщение' }).click();
  22  |   await expect(page.getByText('Сообщение без сети', { exact: true })).toHaveCount(1);
  23  |   const row = page.getByTestId('feed-message').filter({ hasText: 'Сообщение без сети' });
  24  |   await expect(row).toHaveAttribute('data-delivery', 'queued');
  25  |   const stableKey = await row.getAttribute('data-ui-key');
  26  |   await expect(page.getByLabel('Сообщение', { exact: true })).toBeEditable();
  27  |   await context.setOffline(false);
  28  |   await expect(row).toHaveAttribute('data-delivery', 'accepted');
  29  |   await expect(row).toHaveAttribute('data-ui-key', stableKey ?? 'missing-key');
  30  |   await page.reload();
  31  |   await expect(page.getByText('Сообщение без сети', { exact: true })).toHaveCount(1);
  32  | });
  33  | 
  34  | test('a late message response cannot reopen access after a 403', async ({
  35  |   page,
  36  |   browser,
  37  | }) => {
  38  |   await login(page, 'Саша');
  39  |   const created = await apiCreate(page, 'Отозванный доступ');
  40  |   const context = await browser.newContext({ ignoreHTTPSErrors: true });
  41  |   const friend = await context.newPage();
  42  |   await friend.goto(created.invitation_url);
  43  |   await friend.getByRole('button', { name: 'Войти и ответить' }).click();
  44  |   await friend.getByRole('link', { name: 'Войти как Лена' }).click();
  45  |   await friend.getByRole('button', { name: 'Приду', exact: true }).click();
  46  |   await friend.getByRole('link', { name: 'Открыть встречу', exact: true }).click();
  47  |   await expect(friend.getByLabel('Сообщение', { exact: true })).toBeVisible();
  48  |   const release: { response?: () => void } = {};
  49  |   const stored: { response?: () => void } = {};
  50  |   const messageStored = new Promise<void>((resolve) => {
  51  |     stored.response = resolve;
  52  |   });
  53  | 
  54  |   const responseReleased = new Promise<void>((resolve) => {
  55  |     release.response = resolve;
  56  |   });
  57  | 
  58  |   await friend.route(
  59  |     `**/api/v1/meetings/${created.meeting.id}/messages`,
  60  |     async (route) => {
  61  |       const response = await route.fetch();
  62  |       stored.response?.();
  63  |       await responseReleased;
  64  |       await route.fulfill({ response });
  65  |     },
  66  |   );
  67  |   await friend.getByLabel('Сообщение', { exact: true }).fill('Запоздалое подтверждение');
  68  |   await friend.getByRole('button', { name: 'Отправить сообщение' }).click();
  69  |   await messageStored;
  70  |   const leave = await friend.request.put(`/api/v1/meetings/${created.meeting.id}/rsvp`, {
  71  |     headers: {
  72  |       Origin: 'https://127.0.0.1:8444',
  73  |       'X-CSRF-Token': await csrf(friend),
  74  |       'Idempotency-Key': crypto.randomUUID(),
  75  |     },
  76  |     data: { answer: 'not_going', expected_revision: '1' },
  77  |   });
  78  | 
> 79  |   expect(leave.status()).toBe(200);
      |                          ^ Error: expect(received).toBe(expected) // Object.is equality
  80  |   await expect(friend.getByRole('heading', { name: 'Переписка закрыта' })).toBeVisible({
  81  |     timeout: 10000,
  82  |   });
  83  |   release.response?.();
  84  |   await expect(friend.getByLabel('Сообщение', { exact: true })).toHaveCount(0);
  85  |   await expect(friend.getByText('Запоздалое подтверждение', { exact: true })).toHaveCount(
  86  |     0,
  87  |   );
  88  |   await expect(friend.getByRole('link', { name: 'Открыть приглашение' })).toBeVisible();
  89  |   await context.close();
  90  | });
  91  | 
  92  | test('editing text preserves seconds and the selected DST instant', async ({ page }) => {
  93  |   await login(page, 'Саша');
  94  |   const created = await apiCreate(page, 'Точное время');
  95  |   const id = created.meeting.id;
  96  |   const changeTime = await page.request.patch(`/api/v1/meetings/${id}`, {
  97  |     headers: await writeHeaders(page),
  98  |     data: {
  99  |       starts_at: '2026-11-01T01:30:37.123-05:00',
  100 |       timezone: 'America/New_York',
  101 |       expected_revision: created.meeting.revision,
  102 |     },
  103 |   });
  104 | 
  105 |   expect(changeTime.status()).toBe(200);
  106 |   const original = await apiMeeting(page, id);
  107 |   await page.goto(`/meetings/${id}`);
  108 |   await page.getByRole('button', { name: 'Информация о встрече' }).click();
  109 |   await page.getByRole('button', { name: 'Изменить настройки', exact: true }).click();
  110 |   const dialog = page.getByRole('dialog', { name: 'Настройки встречи' });
  111 |   await expectDate(page, '01.11.2026');
  112 |   await expect(dialog.getByRole('textbox', { name: 'Время', exact: true })).toHaveValue(
  113 |     '01:30',
  114 |   );
  115 |   await dialog.getByRole('button', { name: 'Календарь', exact: true }).click();
  116 |   await expect(
  117 |     page.locator('.g-popup').filter({ has: page.getByRole('grid') }),
  118 |   ).toBeVisible();
  119 |   await page.keyboard.press('Escape');
  120 |   await expect(dialog).toBeVisible();
  121 |   await expect(
  122 |     page.locator('.g-popup').filter({ has: page.getByRole('grid') }),
  123 |   ).not.toBeVisible();
  124 |   await dialog.getByLabel(/^Описание/).fill('Описание без изменения даты');
  125 |   await dialog.getByRole('button', { name: 'Сохранить изменения' }).click();
  126 |   await expect(dialog).not.toBeVisible();
  127 |   const updated = await apiMeeting(page, id);
  128 |   expect(updated.starts_at).toBe(original.starts_at);
  129 |   expect(updated.description).toBe('Описание без изменения даты');
  130 | });
  131 | 
```