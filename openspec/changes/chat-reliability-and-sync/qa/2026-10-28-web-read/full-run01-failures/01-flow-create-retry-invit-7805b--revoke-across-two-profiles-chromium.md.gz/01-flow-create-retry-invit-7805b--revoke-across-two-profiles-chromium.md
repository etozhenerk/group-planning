# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 01-flow.spec.ts >> create, retry, invite, join, chat and revoke across two profiles
- Location: tests/01-flow.spec.ts:11:1

# Error details

```
Error: expect(received).toBeLessThan(expected)

Expected: < 1
Received:   4
```

# Page snapshot

```yaml
- generic [ref=f3e3]:
  - link "К содержимому" [ref=f3e4] [cursor=pointer]:
    - /url: "#main"
  - generic [ref=f3e5]: Демостенд · данные хранятся до перезапуска
  - main [ref=f3e8]:
    - generic [ref=f3e9]:
      - link "К моим встречам" [ref=f3e10] [cursor=pointer]:
        - /url: /meetings
      - button "Сведения о встрече «Суббота без спешки»" [ref=f3e17] [cursor=pointer]:
        - heading "Суббота без спешки" [level=1] [ref=f3e18]
        - generic [ref=f3e19]: 24 октября · 19:00 · 2 участника
      - button "Пригласить друзей" [ref=f3e21] [cursor=pointer]
      - button "Информация о встрече" [ref=f3e24] [cursor=pointer]
    - list "Разговор встречи" [ref=f3e29]:
      - listitem [ref=f3e31]:
        - time [ref=f3e32]: Сегодня · 01:11
        - paragraph [ref=f3e33]: Саша создал встречу
      - listitem [ref=f3e35]:
        - time [ref=f3e36]: Сегодня · 01:11
        - paragraph [ref=f3e37]: Лена ответил «Приду»
      - listitem [ref=f3e39]:
        - generic [aria-hidden] [ref=f3e40]: С
        - generic [ref=f3e41]:
          - generic [ref=f3e42]:
            - strong [ref=f3e43]: Саша
            - time [ref=f3e44]: 01:11
          - 'group "Реакции на сообщение: Принесу настолки!" [ref=f3e45]':
            - paragraph [ref=f3e46]: Принесу настолки!
      - listitem [ref=f3e48]:
        - generic [aria-hidden] [ref=f3e49]: Л
        - generic [ref=f3e50]:
          - generic [ref=f3e51]:
            - strong [ref=f3e52]: Лена
            - time [ref=f3e53]: 01:11
          - 'group "Реакции на сообщение: <img src=x onerror=\"window.injected=true\">" [ref=f3e54]':
            - paragraph [ref=f3e55]: <img src=x onerror="window.injected=true">
    - generic [ref=f3e58]:
      - button "Добавить к встрече" [ref=f3e60] [cursor=pointer]
      - generic [ref=f3e63]:
        - generic [ref=f3e64]:
          - generic [ref=f3e65]: Сообщение
          - textbox "Сообщение" [ref=f3e66]:
            - /placeholder: Сообщение…
        - button "Выбрать эмодзи" [ref=f3e67] [cursor=pointer]
      - button "Отправить сообщение" [disabled] [ref=f3e73]
```

# Test source

```ts
  88  |   await expect(page.getByLabel('Сообщение', { exact: true })).toBeVisible();
  89  |   const id = page.url().split('/').at(-1);
  90  | 
  91  |   if (!id) {
  92  |     throw new Error('Missing meeting ID');
  93  |   }
  94  | 
  95  |   return id;
  96  | };
  97  | 
  98  | export const inviteLink = async (page: Page): Promise<string> => {
  99  |   await expect(page.getByLabel('Сообщение', { exact: true })).toBeVisible();
  100 |   const invite = page
  101 |     .getByRole('button', { name: 'Пригласить друзей', exact: true })
  102 |     .first();
  103 | 
  104 |   const throughInfo = !(await invite.isVisible());
  105 | 
  106 |   if (throughInfo) {
  107 |     await page.getByRole('button', { name: 'Информация о встрече', exact: true }).click();
  108 |   }
  109 | 
  110 |   await invite.click();
  111 |   const field = page.getByLabel('Ссылка приглашения');
  112 |   await expect(field).toBeVisible();
  113 |   const url = await field.inputValue();
  114 |   await page.keyboard.press('Escape');
  115 | 
  116 |   if (throughInfo) {
  117 |     await expect(field).not.toBeVisible();
  118 |     await expect(page.locator('dialog:modal')).toHaveCount(1);
  119 |     await page.keyboard.press('Escape');
  120 |   }
  121 | 
  122 |   await expect(page.locator('dialog:modal')).toHaveCount(0);
  123 |   await expect(page.getByLabel('Сообщение', { exact: true })).toBeVisible();
  124 | 
  125 |   return url;
  126 | };
  127 | 
  128 | export const csrf = async (page: Page): Promise<string> => {
  129 |   const response = await page.request.get('/api/v1/me');
  130 |   const raw: unknown = await response.json();
  131 |   const session = sessionSchema.parse(raw);
  132 | 
  133 |   if (!session.csrf_token) {
  134 |     throw new Error('Missing CSRF');
  135 |   }
  136 | 
  137 |   return session.csrf_token;
  138 | };
  139 | 
  140 | export const writeHeaders = async (page: Page, key: string = randomUUID()) => {
  141 |   return {
  142 |     Origin: new URL(page.url()).origin,
  143 |     'X-CSRF-Token': await csrf(page),
  144 |     'Idempotency-Key': key,
  145 |   };
  146 | };
  147 | 
  148 | export const apiMeeting = async (page: Page, id: string) => {
  149 |   const response = await page.request.get(`/api/v1/meetings/${id}`);
  150 |   const raw: unknown = await response.json();
  151 | 
  152 |   return meetingSchema.parse(raw);
  153 | };
  154 | 
  155 | export const apiCreate = async (
  156 |   page: Page,
  157 |   title: string,
  158 |   startsAt = '2099-10-24T19:00:00+03:00',
  159 | ) => {
  160 |   const response = await page.request.post('/api/v1/meetings', {
  161 |     headers: await writeHeaders(page),
  162 |     data: { title, starts_at: startsAt, timezone: 'Europe/Moscow' },
  163 |   });
  164 | 
  165 |   const raw: unknown = await response.json();
  166 | 
  167 |   return createdSchema.parse(raw);
  168 | };
  169 | 
  170 | export const expectMessageSide = async (
  171 |   page: Page,
  172 |   text: string,
  173 |   side: 'left' | 'right',
  174 | ) => {
  175 |   const message = page.getByTestId('feed-message').filter({ hasText: text });
  176 |   const [row, bubble, avatar] = await Promise.all([
  177 |     message.boundingBox(),
  178 |     message.getByTestId('message-bubble').boundingBox(),
  179 |     message.getByTestId('avatar').boundingBox(),
  180 |   ]);
  181 | 
  182 |   if (!row || !bubble || !avatar) {
  183 |     throw new Error('Message is not visible');
  184 |   }
  185 | 
  186 |   const edge = side === 'right' ? row.x + row.width : row.x;
  187 |   const avatarEdge = side === 'right' ? avatar.x + avatar.width : avatar.x;
> 188 |   expect(Math.abs(edge - avatarEdge)).toBeLessThan(1);
      |                                       ^ Error: expect(received).toBeLessThan(expected)
  189 | 
  190 |   if (side === 'right') {
  191 |     expect(avatar.x).toBeGreaterThan(bubble.x + bubble.width);
  192 |   } else {
  193 |     expect(bubble.x).toBeGreaterThan(avatar.x + avatar.width);
  194 |   }
  195 | 
  196 |   expect(bubble.x).toBeGreaterThanOrEqual(row.x);
  197 |   expect(bubble.x + bubble.width).toBeLessThanOrEqual(row.x + row.width + 1);
  198 | };
  199 | 
  200 | export const actionSurface = (page: Page, title: string) =>
  201 |   page
  202 |     .getByRole('main', { name: title, exact: true })
  203 |     .or(page.getByRole('dialog', { name: title, exact: true }));
  204 | 
```