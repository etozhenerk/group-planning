# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 11-calendar-api.spec.ts >> real API: complete day counts, pagination, changed cursor and rescheduled date
- Location: tests/11-calendar-api.spec.ts:6:1

# Error details

```
Error: page.goto: net::ERR_CONNECTION_REFUSED at https://127.0.0.1:8444/meetings
Call log:
  - navigating to "https://127.0.0.1:8444/meetings", waiting until "load"

```

# Page snapshot

```yaml
- generic [ref=f3e3]:
  - link "К содержимому" [ref=f3e4] [cursor=pointer]:
    - /url: "#main"
  - generic [ref=f3e5]: Демостенд · данные хранятся до перезапуска
  - generic [ref=f3e6]:
    - navigation "Основная навигация" [ref=f3e8]:
      - link "Somewhere — на главную" [ref=f3e10] [cursor=pointer]:
        - /url: /
        - generic [ref=f3e11]: somewhere
      - generic [ref=f3e12]:
        - link "Встречи" [ref=f3e13] [cursor=pointer]:
          - /url: /meetings
          - generic [ref=f3e16]: Мои встречи
        - link "Приглашения" [ref=f3e17] [cursor=pointer]:
          - /url: /invitations
        - link "Сообщить о проблеме" [ref=f3e22] [cursor=pointer]:
          - /url: /support
        - link "Профиль" [ref=f3e26] [cursor=pointer]:
          - /url: /profile
          - generic [aria-hidden] [ref=f3e28]: С
          - generic [ref=f3e29]:
            - strong [ref=f3e30]: Саша
            - generic [ref=f3e31]: Мой профиль
    - main [ref=f3e33]:
      - generic [ref=f3e35]:
        - heading "Мои встречи" [level=1] [ref=f3e36]
        - link "Создать встречу" [ref=f3e37] [cursor=pointer]:
          - /url: /meetings/new?date=2088-03-01
          - text: Создать
      - generic [ref=f3e39]:
        - navigation "Период встреч" [ref=f3e40]:
          - button "Предстоящие 76" [pressed] [ref=f3e41] [cursor=pointer]:
            - text: Предстоящие
            - generic [ref=f3e42]: "76"
          - button "Прошедшие 2" [ref=f3e43] [cursor=pointer]:
            - text: Прошедшие
            - generic [ref=f3e44]: "2"
        - navigation "Вид встреч" [ref=f3e45]:
          - button "Список" [ref=f3e46] [cursor=pointer]
          - button "Календарь" [pressed] [ref=f3e48] [cursor=pointer]
      - generic [ref=f3e51]:
        - region "Календарь встреч" [ref=f3e53]:
          - generic [ref=f3e54]:
            - heading "март 2088" [level=2] [ref=f3e55]
            - generic [ref=f3e56]:
              - button "Сегодня" [ref=f3e57] [cursor=pointer]
              - button "Предыдущий месяц" [ref=f3e58] [cursor=pointer]
              - button "Следующий месяц" [ref=f3e61] [cursor=pointer]
          - generic [aria-hidden] [ref=f3e64]:
            - generic [ref=f3e65]: Пн
            - generic [ref=f3e66]: Вт
            - generic [ref=f3e67]: Ср
            - generic [ref=f3e68]: Чт
            - generic [ref=f3e69]: Пт
            - generic [ref=f3e70]: Сб
            - generic [ref=f3e71]: Вс
          - group "Дни месяца" [ref=f3e72]:
            - 'button "1 марта 2088 г., встреч: 1, выбранный день" [active] [pressed] [ref=f3e73] [cursor=pointer]':
              - generic [ref=f3e74]: "1"
            - 'button "2 марта 2088 г., встреч: 0" [ref=f3e77] [cursor=pointer]':
              - generic [ref=f3e78]: "2"
            - 'button "3 марта 2088 г., встреч: 0" [ref=f3e79] [cursor=pointer]':
              - generic [ref=f3e80]: "3"
            - 'button "4 марта 2088 г., встреч: 0" [ref=f3e81] [cursor=pointer]':
              - generic [ref=f3e82]: "4"
            - 'button "5 марта 2088 г., встреч: 0" [ref=f3e83] [cursor=pointer]':
              - generic [ref=f3e84]: "5"
            - 'button "6 марта 2088 г., встреч: 0" [ref=f3e85] [cursor=pointer]':
              - generic [ref=f3e86]: "6"
            - 'button "7 марта 2088 г., встреч: 0" [ref=f3e87] [cursor=pointer]':
              - generic [ref=f3e88]: "7"
            - 'button "8 марта 2088 г., встреч: 0" [ref=f3e89] [cursor=pointer]':
              - generic [ref=f3e90]: "8"
            - 'button "9 марта 2088 г., встреч: 0" [ref=f3e91] [cursor=pointer]':
              - generic [ref=f3e92]: "9"
            - 'button "10 марта 2088 г., встреч: 0" [ref=f3e93] [cursor=pointer]':
              - generic [ref=f3e94]: "10"
            - 'button "11 марта 2088 г., встреч: 0" [ref=f3e95] [cursor=pointer]':
              - generic [ref=f3e96]: "11"
            - 'button "12 марта 2088 г., встреч: 0" [ref=f3e97] [cursor=pointer]':
              - generic [ref=f3e98]: "12"
            - 'button "13 марта 2088 г., встреч: 0" [ref=f3e99] [cursor=pointer]':
              - generic [ref=f3e100]: "13"
            - 'button "14 марта 2088 г., встреч: 0" [ref=f3e101] [cursor=pointer]':
              - generic [ref=f3e102]: "14"
            - 'button "15 марта 2088 г., встреч: 0" [ref=f3e103] [cursor=pointer]':
              - generic [ref=f3e104]: "15"
            - 'button "16 марта 2088 г., встреч: 0" [ref=f3e105] [cursor=pointer]':
              - generic [ref=f3e106]: "16"
            - 'button "17 марта 2088 г., встреч: 0" [ref=f3e107] [cursor=pointer]':
              - generic [ref=f3e108]: "17"
            - 'button "18 марта 2088 г., встреч: 0" [ref=f3e109] [cursor=pointer]':
              - generic [ref=f3e110]: "18"
            - 'button "19 марта 2088 г., встреч: 0" [ref=f3e111] [cursor=pointer]':
              - generic [ref=f3e112]: "19"
            - 'button "20 марта 2088 г., встреч: 0" [ref=f3e113] [cursor=pointer]':
              - generic [ref=f3e114]: "20"
            - 'button "21 марта 2088 г., встреч: 0" [ref=f3e115] [cursor=pointer]':
              - generic [ref=f3e116]: "21"
            - 'button "22 марта 2088 г., встреч: 0" [ref=f3e117] [cursor=pointer]':
              - generic [ref=f3e118]: "22"
            - 'button "23 марта 2088 г., встреч: 0" [ref=f3e119] [cursor=pointer]':
              - generic [ref=f3e120]: "23"
            - 'button "24 марта 2088 г., встреч: 0" [ref=f3e121] [cursor=pointer]':
              - generic [ref=f3e122]: "24"
            - 'button "25 марта 2088 г., встреч: 0" [ref=f3e123] [cursor=pointer]':
              - generic [ref=f3e124]: "25"
            - 'button "26 марта 2088 г., встреч: 0" [ref=f3e125] [cursor=pointer]':
              - generic [ref=f3e126]: "26"
            - 'button "27 марта 2088 г., встреч: 0" [ref=f3e127] [cursor=pointer]':
              - generic [ref=f3e128]: "27"
            - 'button "28 марта 2088 г., встреч: 0" [ref=f3e129] [cursor=pointer]':
              - generic [ref=f3e130]: "28"
            - 'button "29 марта 2088 г., встреч: 0" [ref=f3e131] [cursor=pointer]':
              - generic [ref=f3e132]: "29"
            - 'button "30 марта 2088 г., встреч: 0" [ref=f3e133] [cursor=pointer]':
              - generic [ref=f3e134]: "30"
            - 'button "31 марта 2088 г., встреч: 0" [ref=f3e135] [cursor=pointer]':
              - generic [ref=f3e136]: "31"
            - 'button "1 апреля 2088 г., встреч: 0" [ref=f3e137] [cursor=pointer]':
              - generic [ref=f3e138]: "1"
            - 'button "2 апреля 2088 г., встреч: 0" [ref=f3e139] [cursor=pointer]':
              - generic [ref=f3e140]: "2"
            - 'button "3 апреля 2088 г., встреч: 0" [ref=f3e141] [cursor=pointer]':
              - generic [ref=f3e142]: "3"
            - 'button "4 апреля 2088 г., встреч: 0" [ref=f3e143] [cursor=pointer]':
              - generic [ref=f3e144]: "4"
            - 'button "5 апреля 2088 г., встреч: 0" [ref=f3e145] [cursor=pointer]':
              - generic [ref=f3e146]: "5"
            - 'button "6 апреля 2088 г., встреч: 0" [ref=f3e147] [cursor=pointer]':
              - generic [ref=f3e148]: "6"
            - 'button "7 апреля 2088 г., встреч: 0" [ref=f3e149] [cursor=pointer]':
              - generic [ref=f3e150]: "7"
            - 'button "8 апреля 2088 г., встреч: 0" [ref=f3e151] [cursor=pointer]':
              - generic [ref=f3e152]: "8"
            - 'button "9 апреля 2088 г., встреч: 0" [ref=f3e153] [cursor=pointer]':
              - generic [ref=f3e154]: "9"
            - 'button "10 апреля 2088 г., встреч: 0" [ref=f3e155] [cursor=pointer]':
              - generic [ref=f3e156]: "10"
            - 'button "11 апреля 2088 г., встреч: 0" [ref=f3e157] [cursor=pointer]':
              - generic [ref=f3e158]: "11"
        - region "Встречи выбранного дня" [ref=f3e159]:
          - generic [ref=f3e160]:
            - heading "Понедельник, 1 марта" [level=3] [ref=f3e161]
            - paragraph [ref=f3e162]: 1 встреча
          - article [ref=f3e167]:
            - link [ref=f3e168] [cursor=pointer]:
              - /url: /meetings/31501c07-2370-4d05-90ff-8163bcf1def0
              - time [ref=f3e169]: Пн, 1 марта · 19:00
              - generic [ref=f3e170]:
                - heading "Календарь 1 Вы организатор" [level=2] [ref=f3e172]:
                  - text: Календарь
                  - generic [ref=f3e173]:
                    - generic [ref=f3e174]: "1"
                    - img "Вы организатор" [ref=f3e175]
                - paragraph [ref=f3e177]: Место пока не выбрано
              - 'generic "Участников: 1" [ref=f3e184]':
                - generic "Саша · Организатор" [ref=f3e185]:
                  - generic [aria-hidden] [ref=f3e186]: С
```

# Test source

```ts
  1   | import { expect } from '@playwright/test';
  2   | import type { Page } from '@playwright/test';
  3   | import { randomUUID } from 'node:crypto';
  4   | import { createdSchema, meetingSchema, sessionSchema } from '@/shared/api';
  5   | 
  6   | export const login = async (page: Page, who: 'Саша' | 'Лена') => {
> 7   |   await page.goto('/meetings');
      |              ^ Error: page.goto: net::ERR_CONNECTION_REFUSED at https://127.0.0.1:8444/meetings
  8   |   await page.getByRole('button', { name: 'Войти через Яндекс ID' }).click();
  9   |   await page.getByRole('link', { name: `Войти как ${who}` }).click();
  10  |   await expect(page).toHaveURL(/\/meetings$/);
  11  | };
  12  | 
  13  | export const expectDate = async (page: Page, value: string) => {
  14  |   const compact = page.getByRole('button', { name: 'Дата', exact: true });
  15  | 
  16  |   if (await compact.isVisible()) {
  17  |     await expect(compact).toHaveAttribute('data-date', value);
  18  | 
  19  |     return;
  20  |   }
  21  | 
  22  |   const input = page.getByRole('combobox', { name: 'Дата', exact: true });
  23  |   await expect
  24  |     .poll(async () => (await input.inputValue()).replace(/[\u2066-\u2069]/g, ''))
  25  |     .toBe(value);
  26  | };
  27  | 
  28  | export const setDate = async (page: Page, value: string) => {
  29  |   const compact = page.getByRole('button', { name: 'Дата', exact: true });
  30  |   const mobile = await compact.isVisible();
  31  | 
  32  |   if (mobile) {
  33  |     await compact.click();
  34  |   }
  35  | 
  36  |   const input = page.getByRole(mobile ? 'textbox' : 'combobox', {
  37  |     name: 'Дата',
  38  |     exact: true,
  39  |   });
  40  | 
  41  |   const platform = await page.evaluate(() => {
  42  |     const browserNavigator = navigator as Navigator & {
  43  |       userAgentData?: { platform: string };
  44  |     };
  45  | 
  46  |     return browserNavigator.userAgentData?.platform ?? navigator.platform;
  47  |   });
  48  | 
  49  |   const selectAll = /^Mac/i.test(platform) ? 'Meta+a' : 'Control+a';
  50  |   const [day = '', month = '', year = ''] = value.split('.');
  51  |   await input.press(selectAll);
  52  |   await input.press('ArrowLeft');
  53  |   await input.pressSequentially(String(Number(day)));
  54  |   await input.press(selectAll);
  55  |   await input.press('ArrowRight');
  56  |   await input.pressSequentially(String(Number(month)));
  57  |   await input.press(selectAll);
  58  |   await input.press('ArrowRight');
  59  |   await input.press('ArrowRight');
  60  |   await input.pressSequentially(year);
  61  | 
  62  |   if (mobile) {
  63  |     await page.getByRole('button', { name: 'Готово', exact: true }).click();
  64  |   }
  65  | 
  66  |   await expectDate(page, value);
  67  | };
  68  | 
  69  | export const create = async (
  70  |   page: Page,
  71  |   title: string,
  72  |   cover?: { name: string; mimeType: string; buffer: Buffer },
  73  | ) => {
  74  |   await page.goto('/meetings/new');
  75  |   await page.getByLabel('Название', { exact: true }).fill(title);
  76  |   await setDate(page, '24.10.2099');
  77  |   await page.getByRole('textbox', { name: 'Время', exact: true }).fill('19:00');
  78  |   await page.getByLabel(/^Место/).fill('Лофт «Квартал»');
  79  |   await page.getByLabel(/^Описание/).fill('Пицца и настольные игры.');
  80  | 
  81  |   if (cover) {
  82  |     await page.getByText('Обложка', { exact: true }).click();
  83  |     await page.getByLabel('Выбрать фото', { exact: true }).setInputFiles(cover);
  84  |     await expect(page.getByRole('img', { name: 'Выбранная обложка' })).toBeVisible();
  85  |   }
  86  | 
  87  |   await page.getByRole('button', { name: 'Создать встречу', exact: true }).click();
  88  |   await expect(page.getByLabel('Сообщение', { exact: true })).toBeVisible();
  89  |   const id = page.url().split('/').at(-1);
  90  | 
  91  |   if (!id) {
  92  |     throw new Error('Missing meeting ID');
  93  |   }
  94  | 
  95  |   return id;
  96  | };
  97  | 
  98  | export const inviteLink = async (page: Page): Promise<string> => {
  99  |   await expect(page.getByLabel('Сообщение', { exact: true })).toBeVisible();
  100 |   const invite = page
  101 |     .getByRole('button', { name: 'Пригласить друзей', exact: true })
  102 |     .first();
  103 | 
  104 |   const throughInfo = !(await invite.isVisible());
  105 | 
  106 |   if (throughInfo) {
  107 |     await page.getByRole('button', { name: 'Информация о встрече', exact: true }).click();
```