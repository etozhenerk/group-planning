# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 22-place-poll.spec.ts >> place closes on time with majority and refreshes header
- Location: tests/22-place-poll.spec.ts:127:3

# Error details

```
Error: expect(locator).toHaveCount(expected) failed

Locator:  getByText('Кафе у парка', { exact: true }).visible()
Expected: 2
Received: 1
Timeout:  5000ms

Call log:
  - Expect "toHaveCount" getByText('Кафе у парка', { exact: true }).visible() with timeout 5000ms
  - waiting for getByText('Кафе у парка', { exact: true }).visible()
    14 × locator resolved to 1 element
       - unexpected value "1"

```

# Page snapshot

```yaml
- generic [ref=f3e3]:
  - link "К содержимому" [ref=f3e4] [cursor=pointer]:
    - /url: "#main"
  - generic [ref=f3e5]: Демостенд · данные хранятся до перезапуска
  - generic [ref=f3e6]:
    - navigation "Основная навигация" [ref=f3e8]:
      - link "Somewhere — на главную" [ref=f3e10] [cursor=pointer]:
        - /url: /
        - generic [ref=f3e11]: somewhere
      - generic [ref=f3e12]:
        - link "Встречи" [ref=f3e13] [cursor=pointer]:
          - /url: /meetings
          - generic [ref=f3e16]: Мои встречи
        - link "Приглашения" [ref=f3e17] [cursor=pointer]:
          - /url: /invitations
        - link "Сообщить о проблеме" [ref=f3e22] [cursor=pointer]:
          - /url: /support
        - link "Профиль" [ref=f3e26] [cursor=pointer]:
          - /url: /profile
          - generic [aria-hidden] [ref=f3e28]: С
          - generic [ref=f3e29]:
            - strong [ref=f3e30]: Саша
            - generic [ref=f3e31]: Мой профиль
    - generic [ref=f3e32]:
      - main [ref=f3e33]:
        - generic [ref=f3e34]:
          - link "К моим встречам" [ref=f3e35] [cursor=pointer]:
            - /url: /meetings
          - generic [ref=f3e38]:
            - heading "Итог места" [level=1] [ref=f3e39]
            - paragraph [ref=f3e40]: 1 участник · 24 октября · 19:00
          - button "Пригласить друзей" [ref=f3e42] [cursor=pointer]
          - button "Информация о встрече" [ref=f3e45] [cursor=pointer]
        - generic [ref=f3e50]:
          - list "Разговор встречи" [ref=f3e51]:
            - listitem [ref=f3e53]:
              - time [ref=f3e54]: Сегодня · 01:13
              - paragraph [ref=f3e55]: Саша создал встречу
            - listitem [ref=f3e57]:
              - region "Опрос о месте" [ref=f3e58]:
                - generic [ref=f3e59]:
                  - generic [ref=f3e63]: Саша · 01:13
                  - generic [ref=f3e64]: Опрос
                - heading "Кафе у парка" [level=3] [ref=f3e65]
                - generic [ref=f3e67]:
                  - generic [ref=f3e68]: За · 1
                  - generic [ref=f3e69]: Против · 0
                - generic [ref=f3e70]: Место изменено
          - generic [ref=f3e71]:
            - heading "Позовём остальных?" [level=2] [ref=f3e76]
            - paragraph [ref=f3e77]: Отправьте друзьям ссылку на встречу.После ответа «Приду» они появятся в чате.
            - button "Пригласить друзей" [ref=f3e78] [cursor=pointer]
        - generic [ref=f3e84]:
          - button "Добавить к встрече" [ref=f3e86] [cursor=pointer]
          - generic [ref=f3e89]:
            - generic [ref=f3e90]:
              - generic [ref=f3e91]: Сообщение
              - textbox "Сообщение" [ref=f3e92]:
                - /placeholder: Сообщение…
            - button "Выбрать эмодзи" [ref=f3e93] [cursor=pointer]
          - button "Отправить сообщение" [disabled] [ref=f3e99]
      - complementary [ref=f3e102]:
        - generic [ref=f3e103]:
          - generic [ref=f3e104]:
            - generic [ref=f3e105]:
              - term [ref=f3e106]: Когда
              - definition [ref=f3e107]:
                - generic [ref=f3e108]: 24 октября в 19:00
                - generic [ref=f3e109]: Москва
            - generic [ref=f3e110]:
              - term [ref=f3e111]: Где
              - definition [ref=f3e112]: Место пока не выбрано
          - generic [ref=f3e113]:
            - heading "Кто придёт · 1" [level=3] [ref=f3e114]
            - 'button "Все участники встречи. Придут: 1" [ref=f3e115] [cursor=pointer]':
              - generic "Саша" [ref=f3e116]:
                - generic [aria-hidden] [ref=f3e117]: С
                - text: Саша
```

# Test source

```ts
  53  |       } else {
  54  |         await route.continue();
  55  |       }
  56  |     });
  57  |     await form.getByRole('button', { name: 'Предложить место', exact: true }).click();
  58  |     await expect(form.getByRole('alert')).toHaveText(
  59  |       'Не удалось подтвердить создание опроса. Повторите отправку.',
  60  |     );
  61  |     await expect(form.getByLabel('Новое место')).toHaveValue('Кафе у парка');
  62  |     await expect(
  63  |       form.getByRole('button', { name: 'Повторить отправку' }),
  64  |     ).toBeInViewport();
  65  |     await page.screenshot({
  66  |       path: `test-results/place-form-error-${width}.png`,
  67  |       animations: 'disabled',
  68  |     });
  69  |     await form.getByRole('button', { name: 'Повторить отправку', exact: true }).click();
  70  |     await expect(form).not.toBeVisible();
  71  |     expect(keys).toHaveLength(2);
  72  |     expect(keys[0]).toBeTruthy();
  73  |     expect(keys[1]).toBe(keys[0]);
  74  |     expect(payloads[1]).toBe(payloads[0]);
  75  |     const card = page.getByRole('region', { name: 'Опрос о месте' });
  76  |     await expect(card.getByRole('heading', { name: 'Кафе у парка' })).toBeVisible();
  77  |     await expect(card.getByText('Там тихо и есть большой стол')).toBeVisible();
  78  |     await expect(card).toHaveCSS('background-color', 'rgb(48, 49, 56)');
  79  |     await card.getByRole('button', { name: 'За · 0', exact: true }).click();
  80  |     await expect(
  81  |       card.getByRole('button', { name: 'За · 1', exact: true }),
  82  |     ).toHaveAttribute('aria-pressed', 'true');
  83  |     expect((await apiMeeting(page, meeting.id)).place).toBeNull();
  84  |     await card.getByRole('button', { name: 'Против · 0', exact: true }).click();
  85  |     await expect(
  86  |       card.getByRole('button', { name: 'Против · 1', exact: true }),
  87  |     ).toHaveAttribute('aria-pressed', 'true');
  88  |     await expect(
  89  |       card.getByRole('button', { name: 'За · 0', exact: true }),
  90  |     ).toHaveAttribute('aria-pressed', 'false');
  91  |     await expect(
  92  |       card.getByRole('button', { name: 'Против · 1', exact: true }),
  93  |     ).toHaveAttribute('aria-pressed', 'true');
  94  |     await expect(page.locator('body')).toHaveJSProperty('scrollWidth', width);
  95  |     await page.screenshot({
  96  |       path: `test-results/place-vote-${width}.png`,
  97  |       animations: 'disabled',
  98  |     });
  99  |     const activeForm = await openForm(page);
  100 |     await activeForm.getByLabel('Новое место').fill('Другая площадка');
  101 |     await activeForm.getByRole('button', { name: 'Предложить место' }).click();
  102 |     await expect(activeForm.getByRole('alert')).toContainText('уже есть открытый опрос');
  103 |     await page.keyboard.press('Escape');
  104 |     await expect(activeForm).not.toBeVisible();
  105 |     await expect(page.getByRole('button', { name: 'Добавить к встрече' })).toBeFocused();
  106 |     const current = await apiMeeting(page, meeting.id);
  107 |     const changed = await page.request.patch(base, {
  108 |       headers: await writeHeaders(page),
  109 |       data: { place: 'У Саши дома', expected_revision: current.revision },
  110 |     });
  111 | 
  112 |     expect(changed.status()).toBe(200);
  113 |     await expect(
  114 |       card.getByText('Опрос отменён: организатор изменил место', { exact: true }),
  115 |     ).toBeVisible({ timeout: 10000 });
  116 |     await expect(card.getByRole('button', { name: /За ·|Против ·/ })).toHaveCount(0);
  117 | 
  118 |     if (width < 1170) {
  119 |       await page.getByRole('button', { name: 'Информация о встрече' }).click();
  120 |     }
  121 | 
  122 |     await expect(page.getByText('У Саши дома', { exact: true }).first()).toBeVisible();
  123 |   });
  124 | }
  125 | 
  126 | for (const yes of [true, false]) {
  127 |   test(`place closes on time with ${yes ? 'majority' : 'zero votes'} and refreshes header`, async ({
  128 |     page,
  129 |   }) => {
  130 |     await login(page, 'Саша');
  131 |     const { meeting } = await apiCreate(page, 'Итог места');
  132 |     await seed(page, meeting.id, 9);
  133 |     await page.goto(`/meetings/${meeting.id}`);
  134 |     const card = page.getByRole('region', { name: 'Опрос о месте' });
  135 | 
  136 |     if (yes) {
  137 |       await card.getByRole('button', { name: 'За · 0' }).click();
  138 |       await expect(
  139 |         card.getByRole('button', { name: 'За · 1', exact: true }),
  140 |       ).toHaveAttribute('aria-pressed', 'true');
  141 |     }
  142 | 
  143 |     expect((await apiMeeting(page, meeting.id)).place).toBeNull();
  144 |     await expect(
  145 |       card.getByText(yes ? 'Место изменено' : 'Место осталось прежним', { exact: true }),
  146 |     ).toBeVisible({ timeout: 15000 });
  147 |     await expect(card.getByRole('button')).toHaveCount(0);
  148 |     expect((await apiMeeting(page, meeting.id)).place).toBe(yes ? 'Кафе у парка' : null);
  149 | 
  150 |     if (yes) {
  151 |       await expect(
  152 |         page.getByText('Кафе у парка', { exact: true }).filter({ visible: true }),
> 153 |       ).toHaveCount(2);
      |         ^ Error: expect(locator).toHaveCount(expected) failed
  154 |     }
  155 | 
  156 |     await page.screenshot({
  157 |       path: `test-results/place-result-${yes ? 'applied' : 'rejected'}.png`,
  158 |       fullPage: true,
  159 |     });
  160 |   });
  161 | }
  162 | 
  163 | test('failed vote preserves state, retry keeps key, late reply cannot restore lost membership', async ({
  164 |   page,
  165 |   browser,
  166 | }) => {
  167 |   await login(page, 'Саша');
  168 |   const created = await apiCreate(page, 'Голос и доступ');
  169 |   const poll = await seed(page, created.meeting.id);
  170 |   const context = await browser.newContext({ ignoreHTTPSErrors: true });
  171 | 
  172 |   try {
  173 |     const friend = await context.newPage();
  174 |     await login(friend, 'Лена');
  175 |     const invitation = new URL(created.invitation_url).pathname.replace(
  176 |       '/i/',
  177 |       '/api/v1/invitations/',
  178 |     );
  179 | 
  180 |     const joined = await friend.request.put(`${invitation}/rsvp`, {
  181 |       headers: await writeHeaders(friend),
  182 |       data: { answer: 'going', expected_revision: '0' },
  183 |     });
  184 | 
  185 |     expect(joined.status()).toBe(200);
  186 |     const base = `/api/v1/meetings/${created.meeting.id}/place-polls/${poll.id}`;
  187 |     const keys: (string | undefined)[] = [];
  188 |     const latch = { release: () => {} };
  189 | 
  190 |     const gate = new Promise<void>((resolve) => {
  191 |       latch.release = resolve;
  192 |     });
  193 | 
  194 |     let held = false;
  195 |     await friend.route(`**${base}/vote`, async (route) => {
  196 |       keys.push(route.request().headers()['idempotency-key']);
  197 | 
  198 |       if (keys.length === 1) {
  199 |         await route.abort('failed');
  200 |       } else if (keys.length === 3) {
  201 |         const response = await route.fetch();
  202 |         held = true;
  203 |         await gate;
  204 |         await route.fulfill({ response });
  205 |       } else {
  206 |         await route.continue();
  207 |       }
  208 |     });
  209 |     await friend.goto(`/meetings/${created.meeting.id}`);
  210 |     const card = friend.getByRole('region', { name: 'Опрос о месте' });
  211 |     await card.getByRole('button', { name: 'За · 0' }).click();
  212 |     await expect(card.getByRole('alert')).toContainText('Не удалось сохранить голос');
  213 |     await expect(card.getByRole('button', { pressed: true })).toHaveCount(0);
  214 |     await card.getByRole('button', { name: 'Повторить' }).click();
  215 |     await expect(
  216 |       card.getByRole('button', { name: 'За · 1', exact: true }),
  217 |     ).toHaveAttribute('aria-pressed', 'true');
  218 |     expect(keys[0]).toBeTruthy();
  219 |     expect(keys[1]).toBe(keys[0]);
  220 |     await card.getByRole('button', { name: 'Против · 0' }).click();
  221 |     await expect.poll(() => held).toBe(true);
  222 |     const pending = card.getByRole('button', { name: 'Против · 0' });
  223 |     await expect(pending).toBeDisabled();
  224 |     await expect(pending).toHaveText('');
  225 |     await expect(card.getByRole('button', { name: 'За · 1' })).toBeDisabled();
  226 |     const left = await friend.request.put(`${invitation}/rsvp`, {
  227 |       headers: await writeHeaders(friend),
  228 |       data: { answer: 'maybe', expected_revision: '1' },
  229 |     });
  230 | 
  231 |     expect(left.status()).toBe(200);
  232 |     await expect(card).toHaveCount(0, { timeout: 10000 });
  233 |     latch.release();
  234 |     await expect(friend.getByRole('region', { name: 'Опрос о месте' })).toHaveCount(0);
  235 |   } finally {
  236 |     await context.close();
  237 |   }
  238 | });
  239 | 
```