# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: 34-telegram-chat.spec.ts >> opening the emoji dock preserves the reading position and the new-message action stays above it
- Location: tests/34-telegram-chat.spec.ts:152:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: 'Новые сообщения ↓' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('button', { name: 'Новые сообщения ↓' }) with timeout 5000ms
  - waiting for getByRole('button', { name: 'Новые сообщения ↓' })

```

```yaml
- link "К содержимому":
  - /url: "#main"
- text: Демостенд · данные хранятся до перезапуска
- main:
  - link "К моим встречам":
    - /url: /meetings
  - button "Сведения о встрече «Позиция чтения»":
    - heading "Позиция чтения" [level=1]
    - text: 24 октября · 19:00 · 1 участник
  - button "Пригласить друзей"
  - button "Информация о встрече"
  - list "Разговор встречи":
    - listitem:
      - time: Сегодня · 01:18
      - paragraph: Саша создал встречу
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 0"':
        - paragraph: Сообщение истории 0
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 1"':
        - paragraph: Сообщение истории 1
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 2"':
        - paragraph: Сообщение истории 2
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 3"':
        - paragraph: Сообщение истории 3
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 4"':
        - paragraph: Сообщение истории 4
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 5"':
        - paragraph: Сообщение истории 5
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 6"':
        - paragraph: Сообщение истории 6
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 7"':
        - paragraph: Сообщение истории 7
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 8"':
        - paragraph: Сообщение истории 8
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 9"':
        - paragraph: Сообщение истории 9
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 10"':
        - paragraph: Сообщение истории 10
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 11"':
        - paragraph: Сообщение истории 11
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 12"':
        - paragraph: Сообщение истории 12
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 13"':
        - paragraph: Сообщение истории 13
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 14"':
        - paragraph: Сообщение истории 14
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 15"':
        - paragraph: Сообщение истории 15
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 16"':
        - paragraph: Сообщение истории 16
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 17"':
        - paragraph: Сообщение истории 17
    - listitem:
      - strong: Саша
      - time: 01:18
      - 'group "Реакции на сообщение: Сообщение истории 18"':
        - paragraph: Сообщение истории 18
  - button "К новым сообщениям"
  - button "Добавить к встрече"
  - text: Сообщение
  - textbox "Сообщение":
    - /placeholder: Сообщение…
  - button "Выбрать эмодзи"
  - button "Отправить сообщение" [disabled]
```

# Test source

```ts
  82  |     await expect(input).toBeInViewport({ ratio: 1 });
  83  |     await expect(
  84  |       page.getByRole('button', { name: 'Отправить сообщение' }),
  85  |     ).toBeInViewport({ ratio: 1 });
  86  |     await expect(page.locator('[data-emoji-panel]')).toHaveAttribute(
  87  |       'data-motion',
  88  |       'open',
  89  |     );
  90  |     const inputBox = await input.boundingBox();
  91  |     const dockBox = await dock.boundingBox();
  92  |     expect(inputBox && dockBox && inputBox.y + inputBox.height <= dockBox.y).toBe(true);
  93  |     await row.getByTestId('message-actions').press('Enter');
  94  |     await expect(dock).toHaveCount(0);
  95  |     const reactions = page.getByRole('dialog', { name: 'Реакция', exact: true });
  96  |     await reactions.getByRole('button', { name: 'Все эмодзи' }).click();
  97  |     await expect(reactions).toBeInViewport({ ratio: 1 });
  98  |     await expect(input).toBeInViewport({ ratio: 1 });
  99  |     await page.screenshot({
  100 |       path: test
  101 |         .info()
  102 |         .outputPath(`full-reactions-${viewport.width}-${viewport.height}.png`),
  103 |     });
  104 |     await page.keyboard.press('Escape');
  105 |     await expect(row.getByTestId('message-actions')).toBeFocused();
  106 |     expect(
  107 |       await page.evaluate(() => document.documentElement.scrollWidth),
  108 |     ).toBeLessThanOrEqual(viewport.width);
  109 |   }
  110 | });
  111 | 
  112 | test('settings and sharing return to the same information sheet and retain the draft', async ({
  113 |   page,
  114 | }) => {
  115 |   await page.setViewportSize({ width: 390, height: 844 });
  116 |   await login(page, 'Саша');
  117 |   const { meeting } = await apiCreate(page, 'Родительская панель');
  118 |   await page.goto(`/meetings/${meeting.id}`);
  119 |   await page.getByLabel('Сообщение', { exact: true }).fill('Черновик сообщения');
  120 |   await page.getByRole('button', { name: 'Информация о встрече' }).click();
  121 |   const info = page.getByRole('dialog', { name: meeting.title, exact: true });
  122 |   await info.getByRole('button', { name: 'Настройки встречи' }).click();
  123 |   const settings = page.getByRole('dialog', { name: 'Настройки встречи' });
  124 |   await expect(page.locator('dialog:modal')).toHaveCount(1);
  125 |   await settings.getByLabel('Название', { exact: true }).fill('Несохранённое название');
  126 |   await expect(settings.getByLabel('Название', { exact: true })).toHaveCSS(
  127 |     'font-size',
  128 |     '16px',
  129 |   );
  130 |   await page.screenshot({ path: test.info().outputPath('meeting-settings-draft.png') });
  131 |   await page.goBack();
  132 |   await expect(info).toBeVisible();
  133 |   await expect(info.getByRole('button', { name: 'Настройки встречи' })).toBeFocused();
  134 |   await info.getByRole('button', { name: 'Настройки встречи' }).click();
  135 |   await expect(settings.getByLabel('Название', { exact: true })).toHaveValue(
  136 |     'Несохранённое название',
  137 |   );
  138 |   await settings.getByRole('button', { name: 'Закрыть', exact: true }).click();
  139 |   await info.getByRole('button', { name: 'Пригласить друзей' }).click();
  140 |   const share = page.getByRole('dialog', { name: 'Пригласить друзей', exact: true });
  141 |   await expect(page.locator('dialog:modal')).toHaveCount(1);
  142 |   await share.getByRole('button', { name: 'Закрыть', exact: true }).click();
  143 |   await expect(info).toBeVisible();
  144 |   await expect(info.getByRole('button', { name: 'Пригласить друзей' })).toBeFocused();
  145 |   await page.screenshot({ path: test.info().outputPath('meeting-info-return.png') });
  146 |   await info.getByRole('button', { name: 'Закрыть', exact: true }).click();
  147 |   await expect(page.getByLabel('Сообщение', { exact: true })).toHaveValue(
  148 |     'Черновик сообщения',
  149 |   );
  150 | });
  151 | 
  152 | test('opening the emoji dock preserves the reading position and the new-message action stays above it', async ({
  153 |   page,
  154 | }) => {
  155 |   await page.setViewportSize({ width: 390, height: 844 });
  156 |   await login(page, 'Саша');
  157 |   const { meeting } = await apiCreate(page, 'Позиция чтения');
  158 |   const headers = await writeHeaders(page);
  159 |   const send = async (text: string) => {
  160 |     const key = randomUUID();
  161 |     const response = await page.request.post(`/api/v1/meetings/${meeting.id}/messages`, {
  162 |       headers: { ...headers, 'Idempotency-Key': key },
  163 |       data: { text, client_request_id: key },
  164 |     });
  165 | 
  166 |     expect(response.status()).toBe(201);
  167 |   };
  168 | 
  169 |   for (let index = 0; index < 25; index++) {
  170 |     await send(`Сообщение истории ${index}`);
  171 |   }
  172 | 
  173 |   await page.goto(`/meetings/${meeting.id}`);
  174 |   const history = page.getByRole('list', { name: 'Разговор встречи' }).locator('..');
  175 |   await expect(page.getByText('Сообщение истории 24', { exact: true })).toBeInViewport();
  176 |   await history.evaluate((node) => {
  177 |     node.scrollTop = 120;
  178 |     node.dispatchEvent(new Event('scroll'));
  179 |   });
  180 |   await send('Новое сообщение внизу');
  181 |   const latest = page.getByRole('button', { name: 'Новые сообщения ↓' });
> 182 |   await expect(latest).toBeVisible();
      |                        ^ Error: expect(locator).toBeVisible() failed
  183 |   const before = await history.evaluate((node) => node.scrollTop);
  184 |   await page.getByRole('button', { name: 'Выбрать эмодзи', exact: true }).click();
  185 |   await expect(page.getByRole('region', { name: 'Выбор эмодзи' })).toBeVisible();
  186 |   await expect
  187 |     .poll(() => history.evaluate((node) => node.scrollTop))
  188 |     .toBeCloseTo(before, 0);
  189 |   await expect(latest).toBeInViewport({ ratio: 1 });
  190 |   await expect(page.locator('[data-emoji-panel]')).toHaveAttribute('data-motion', 'open');
  191 |   const latestBox = await latest.boundingBox();
  192 |   const inputBox = await page.getByLabel('Сообщение', { exact: true }).boundingBox();
  193 |   expect(latestBox && inputBox && latestBox.y + latestBox.height <= inputBox.y).toBe(
  194 |     true,
  195 |   );
  196 |   await page.screenshot({
  197 |     path: test.info().outputPath('reading-position-emoji-dock.png'),
  198 |   });
  199 |   await page.keyboard.press('Escape');
  200 |   await expect(page.locator('[data-emoji-panel]')).toHaveCount(0);
  201 |   expect(await history.evaluate((node) => node.scrollTop)).toBeCloseTo(before, 0);
  202 |   await latest.click();
  203 |   await expect(latest).toHaveCount(0);
  204 |   await expect(page.getByText('Новое сообщение внизу', { exact: true })).toBeInViewport();
  205 |   await page.getByRole('button', { name: 'Выбрать эмодзи', exact: true }).click();
  206 |   await expect(page.locator('[data-emoji-panel]')).toHaveAttribute('data-motion', 'open');
  207 |   await expect(page.getByText('Новое сообщение внизу', { exact: true })).toBeInViewport();
  208 |   await page.keyboard.press('Escape');
  209 |   await expect(page.locator('[data-emoji-panel]')).toHaveCount(0);
  210 |   await expect(page.getByText('Новое сообщение внизу', { exact: true })).toBeInViewport();
  211 | });
  212 | 
  213 | test('reaction people replace the picker and browser Back returns to the same message', async ({
  214 |   page,
  215 | }) => {
  216 |   await page.setViewportSize({ width: 390, height: 844 });
  217 |   await login(page, 'Саша');
  218 |   const { meeting } = await apiCreate(page, 'Люди и реакции');
  219 |   await page.goto(`/meetings/${meeting.id}`);
  220 |   await page.getByLabel('Сообщение', { exact: true }).fill('Беру настолки');
  221 |   await page.getByRole('button', { name: 'Отправить сообщение' }).click();
  222 |   const row = page.getByTestId('feed-message').filter({ hasText: 'Беру настолки' });
  223 |   await row.getByTestId('message-actions').press('Enter');
  224 |   const picker = page.getByRole('dialog', { name: 'Реакция', exact: true });
  225 |   await picker.getByRole('button', { name: '❤️', exact: true }).click();
  226 |   const reaction = row.getByRole('button', { name: '❤️: 1', exact: true });
  227 |   await expect(reaction).toHaveAttribute('aria-pressed', 'true');
  228 |   await expect(row.getByRole('button', { name: 'Добавить реакцию' })).toHaveCount(0);
  229 |   await expect(row.getByRole('button', { name: 'Кто отреагировал' })).toHaveCount(0);
  230 |   await expect(picker).toHaveCount(0);
  231 |   await row.getByTestId('message-actions').press('Enter');
  232 |   await expect(picker).toBeVisible();
  233 |   await expect(picker.getByRole('button', { name: '❤️', exact: true })).toBeFocused();
  234 |   const opener = reaction;
  235 |   await opener.press('Shift+F10');
  236 |   const people = page.getByRole('dialog', { name: 'Кто отреагировал', exact: true });
  237 |   await expect(people).toBeVisible();
  238 |   await expect(picker).toHaveCount(0);
  239 |   await expect(page.locator('dialog:modal')).toHaveCount(1);
  240 |   const filter = people.getByRole('button', { name: 'Реакция ❤️', exact: true });
  241 |   await expect(filter).toHaveAttribute('aria-pressed', 'true');
  242 |   await filter.click();
  243 |   await expect(filter).toBeFocused();
  244 |   await expect(people.getByRole('list')).toContainText('Саша');
  245 |   await page.screenshot({ path: test.info().outputPath('reaction-people-filter.png') });
  246 |   await page.goBack();
  247 |   await expect(people).not.toBeVisible();
  248 |   await expect(page).toHaveURL(new RegExp(`/meetings/${meeting.id}$`));
  249 |   await expect(opener).toBeFocused();
  250 |   await expect(reaction).toHaveAttribute('aria-pressed', 'true');
  251 |   await reaction.click();
  252 |   await expect(reaction).toHaveCount(0);
  253 |   const draft = page.getByLabel('Сообщение', { exact: true });
  254 |   await draft.fill('Черновик под приглашением');
  255 |   const timeline = page.getByRole('list', { name: 'Разговор встречи' });
  256 |   const position = await timeline.evaluate((element) => element.parentElement?.scrollTop);
  257 |   await row.getByTestId('message-actions').press('Enter');
  258 |   await expect(picker).toBeVisible();
  259 |   await page
  260 |     .locator('main#main > header')
  261 |     .getByRole('button', {
  262 |       name: 'Пригласить друзей',
  263 |       exact: true,
  264 |     })
  265 |     .click();
  266 |   const share = page.getByRole('dialog', { name: 'Пригласить друзей', exact: true });
  267 |   await expect(share).toBeVisible();
  268 |   await expect(picker).toHaveCount(0);
  269 |   await page.keyboard.press('Escape');
  270 |   await expect(share).not.toBeVisible();
  271 |   await expect(picker).toHaveCount(0);
  272 |   await expect(
  273 |     page
  274 |       .locator('main#main > header')
  275 |       .getByRole('button', { name: 'Пригласить друзей', exact: true }),
  276 |   ).toBeFocused();
  277 |   await expect(draft).toHaveValue('Черновик под приглашением');
  278 |   expect(await timeline.evaluate((element) => element.parentElement?.scrollTop)).toBe(
  279 |     position,
  280 |   );
  281 |   await expect(page).toHaveURL(new RegExp(`/meetings/${meeting.id}$`));
  282 | });
```