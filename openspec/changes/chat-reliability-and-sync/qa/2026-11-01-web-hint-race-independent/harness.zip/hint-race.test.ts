import {expect,it,vi} from 'vitest';
import {writeFile} from 'node:fs/promises';
import {createChatUpdates} from '/Users/misha/Documents/Codex/projects/group-planning/frontend/web/src/entities/meeting/model/createChatUpdates';
it('does not lose hint when successful in-flight GET completes before coalesce100ms',async()=>{
 vi.useFakeTimers();vi.setSystemTime(0);let callbacks:any,finish:undefined|(()=>void),remote=1,applied=0,calls=0;const timeline:any[]=[];
 const owner=createChatUpdates({realtime:true,random:()=>0.5,authenticate:async()=>{},terminal:()=>false,connect:e=>{callbacks=e;return()=>{};},refresh:async()=>{const version=remote;calls++;timeline.push({event:'GET-start',at:Date.now(),version});if(calls===1)await new Promise<void>(r=>finish=r);applied=version;timeline.push({event:'GET-finish',at:Date.now(),version});}});
 try{await vi.advanceTimersByTimeAsync(0);callbacks.ready();await vi.advanceTimersByTimeAsync(0);expect(calls).toBe(1);remote=2;callbacks.hint();timeline.push({event:'hint2',at:Date.now()});await vi.advanceTimersByTimeAsync(50);finish!();await vi.advanceTimersByTimeAsync(0);await vi.advanceTimersByTimeAsync(1000);await writeFile('/tmp/somewhere-web-sdd-independent/fallback-final/hint-race.json',JSON.stringify({calls,applied,remote,timeline,expectedCalls:2,expectedApplied:2},null,2));expect(calls).toBe(2);expect(applied).toBe(2);}finally{owner.stop();vi.useRealTimers();}
});
