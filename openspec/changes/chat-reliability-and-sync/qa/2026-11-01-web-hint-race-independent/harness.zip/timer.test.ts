import {afterEach,expect,it,vi} from 'vitest';
import {writeFile} from 'node:fs/promises';
import {createChatUpdates} from '/Users/misha/Documents/Codex/projects/group-planning/frontend/web/src/entities/meeting/model/createChatUpdates';
afterEach(()=>vi.useRealTimers());
const out='/tmp/somewhere-web-sdd-independent/fallback-final/evidence';
it('healthy90s and repeated hints remain serial and catch up latest state',async()=>{
 vi.useFakeTimers();vi.setSystemTime(0);let callbacks:any,calls=0,inflight=0,max=0,latest=0,applied=0,resolve:undefined|(()=>void);
 const owner=createChatUpdates({realtime:true,random:()=>0.5,authenticate:async()=>{},terminal:()=>false,connect:e=>{callbacks=e;return()=>{};},refresh:async()=>{calls++;inflight++;max=Math.max(max,inflight);if(calls===2)await new Promise<void>(r=>resolve=r);applied=latest;inflight--;}});
 try{await vi.advanceTimersByTimeAsync(0);callbacks.ready();await vi.advanceTimersByTimeAsync(90000);expect(calls).toBe(1);latest=1;callbacks.hint();await vi.advanceTimersByTimeAsync(100);expect(calls).toBe(2);for(let i=0;i<20;i++){latest=Math.max(latest,20-i);callbacks.hint();}await vi.advanceTimersByTimeAsync(100);expect(calls).toBe(2);resolve!();await vi.advanceTimersByTimeAsync(0);expect(calls).toBe(3);expect(applied).toBe(20);expect(max).toBe(1);await vi.advanceTimersByTimeAsync(90000);expect(calls).toBe(3);await writeFile(out+'/healthy-burst-timer.json',JSON.stringify({idleMs:180000,coalescedBurstHints:20,maxInFlight:max,calls,latestApplied:applied}));}finally{owner.stop();}
});
for(const httpFails of [false,true])it(`protocol90 fallback3-6-12-30 when HTTP ${httpFails?'fails':'works'}`,async()=>{
 vi.useFakeTimers();vi.setSystemTime(0);const calls:number[]=[];const owner=createChatUpdates({realtime:true,random:()=>0.5,authenticate:async()=>{},terminal:()=>false,connect:()=>()=>{},refresh:async()=>{calls.push(Date.now());if(httpFails)throw Error('controlled HTTP failure');}});
 try{await vi.advanceTimersByTimeAsync(100000);const actual=calls.slice(0,5),gaps=actual.map((x,i)=>x-(i?actual[i-1]:10000));await writeFile(`${out}/fallback-${httpFails?'http-error':'http-working'}.json`,JSON.stringify({jitterRandom:0.5,realtimeStableFailure:true,httpFails,graceMs:10000,actualCallTimes:actual,actualGaps:gaps,expectedFirstFourCallTimes:[13000,19000,31000,61000]},null,2));expect(calls.slice(0,4)).toEqual([13000,19000,31000,61000]);expect(calls[4]).toBe(91000);}finally{owner.stop();}
});
it('legacy HTTP stays3s after success, errors back off then successful refresh resets',async()=>{
 vi.useFakeTimers();vi.setSystemTime(0);const calls:number[]=[];let fail=false;const owner=createChatUpdates({realtime:false,random:()=>0.5,authenticate:async()=>{},terminal:()=>false,connect:()=>()=>{},refresh:async()=>{calls.push(Date.now());if(fail)throw Error('controlled');}});
 try{await vi.advanceTimersByTimeAsync(9000);expect(calls).toEqual([0,3000,6000,9000]);fail=true;await vi.advanceTimersByTimeAsync(54000);expect(calls.slice(4)).toEqual([12000,18000,30000,60000]);fail=false;await vi.advanceTimersByTimeAsync(27000);expect(calls.at(-1)).toBe(90000);await vi.advanceTimersByTimeAsync(3000);expect(calls.at(-1)).toBe(93000);await writeFile(out+'/legacy-success-error-reset.json',JSON.stringify({calls}));}finally{owner.stop();}
});
it('jitter remains bounded on each3-6-12-30 base including saturated30',async()=>{
 vi.useFakeTimers();vi.setSystemTime(0);const calls:number[]=[];let r=0;const owner=createChatUpdates({realtime:true,random:()=>r++%2?1:0,authenticate:async()=>{},terminal:()=>false,connect:()=>()=>{},refresh:async()=>{calls.push(Date.now());}});
 try{await vi.advanceTimersByTimeAsync(100000);const expectedGaps=[2550,6900,10200,34500,25500];const gaps=calls.slice(0,5).map((t,i)=>t-(i?calls[i-1]:10000));for(let i=0;i<5;i++)expect(Math.abs(gaps[i]-expectedGaps[i])).toBeLessThanOrEqual(1);await writeFile(out+'/jitter-bounds.json',JSON.stringify({random:[0,1,0,1,0],calls,baseDelays:[3000,6000,12000,30000,30000]}));}finally{owner.stop();}
});
it('healthy recovery cancels fallback, later outage restarts at3 and stop cancels all callbacks',async()=>{
 vi.useFakeTimers();vi.setSystemTime(0);const calls:number[]=[];let events:any;const owner=createChatUpdates({realtime:true,random:()=>0.5,authenticate:async()=>{},terminal:()=>false,connect:e=>{events=e;return()=>{};},refresh:async()=>{calls.push(Date.now());}});
 try{await vi.advanceTimersByTimeAsync(31000);expect(calls).toEqual([13000,19000,31000]);events.ready();await vi.advanceTimersByTimeAsync(0);expect(calls.at(-1)).toBe(31000);await vi.advanceTimersByTimeAsync(90000);expect(calls).toHaveLength(4);events.unavailable();await vi.advanceTimersByTimeAsync(12999);expect(calls).toHaveLength(4);await vi.advanceTimersByTimeAsync(1);expect(calls.at(-1)).toBe(134000);owner.stop();events.ready();events.hint();await vi.advanceTimersByTimeAsync(90000);expect(calls).toHaveLength(5);await writeFile(out+'/healthy-restart-stop.json',JSON.stringify({calls}));}finally{owner.stop();}
});
